export interface Weight {
  vori: number;
  ana: number;
  roti: number;
  point: number;
}

export interface Transaction {
  id: string;
  product: string;
  purchaseDate: string;
  saleDate: string | null;
  tokenNumber: string | null;
  weight: Weight | null;
  totalWeightInVori: number | null;
  purchasePrice: number | null;
  salePrice: number | null;
  profit: number | null;
  comment: string | null;
  isSoldManually?: boolean;
}

export interface Sheet {
  id: string;
  name: string;
  transactions: Transaction[];
}

export interface AppState {
  sheets: { [id: string]: Sheet };
  activeSheetId: string;
}