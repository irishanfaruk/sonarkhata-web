# GitHub + Netlify Deployment - সম্পূর্ণ Step by Step Guide (বাংলা)

## Overview
এই guide-এ আপনি শিখবেন কিভাবে আপনার Sonarkhata web version-কে GitHub-এ upload করে Netlify-এ host করতে পারবেন।

---

## Part 1: GitHub Setup (Code Upload)

### Step 1: GitHub Account তৈরি করুন
1. https://github.com এ যান
2. "Sign up" ক্লিক করুন
3. Email, password দিয়ে account তৈরি করুন
4. Email verify করুন

### Step 2: নতুন Repository তৈরি করুন
1. GitHub-এ login করুন
2. Top right corner-এ **"+"** icon → **"New repository"** ক্লিক করুন
3. **Repository name:** `sonarkhata-web` (বা আপনার পছন্দমতো)
4. **Description (optional):** "Sonarkhata - Gold Inventory Management Web App"
5. **Public** select করুন (Netlify free plan-এর জন্য Public repository দরকার)
6. ✅ **"Add a README file"** UNCHECK করুন (আমাদের code আছে)
7. **"Create repository"** ক্লিক করুন

### Step 3: Git Install করুন (যদি না থাকে)
1. https://git-scm.com/download/win এ যান
2. Download করুন
3. Install করুন (default options select করুন)
4. Install শেষ হলে terminal restart করুন

### Step 4: Code GitHub-এ Upload করুন

**Terminal/Command Prompt খুলুন:**

```bash
# Web version folder-এ যান
cd D:\sonarkhata\sonarkhata-web

# Git initialize করুন
git init

# সব files add করুন
git add .

# First commit করুন
git commit -m "Initial commit - Sonarkhata Web Version"

# GitHub repository-এর URL add করুন
# (YOUR_USERNAME এবং YOUR_REPO_NAME replace করুন)
git remote add origin https://github.com/YOUR_USERNAME/sonarkhata-web.git

# Code push করুন
git branch -M main
git push -u origin main
```

**Note:** প্রথমবার push করলে GitHub username এবং password/token চাইবে।

### Step 5: Personal Access Token তৈরি করুন (যদি password কাজ না করে)

1. GitHub → আপনার profile picture → **Settings**
2. Left sidebar → **Developer settings**
3. **Personal access tokens** → **Tokens (classic)**
4. **"Generate new token"** → **"Generate new token (classic)"**
5. **Note:** "Netlify Deploy" লিখুন
6. **Expiration:** 90 days (বা আপনার পছন্দ)
7. **Scopes:** ✅ `repo` (full control) check করুন
8. **"Generate token"** ক্লিক করুন
9. **Token copy করুন** (একবারই দেখবেন, save করে রাখুন!)
10. Terminal-এ password-এর জায়গায় এই token paste করুন

---

## Part 2: Netlify Setup (Hosting)

### Step 1: Netlify Account তৈরি করুন
1. https://www.netlify.com এ যান
2. **"Sign up"** ক্লিক করুন
3. **"GitHub"** select করুন
4. GitHub account দিয়ে authorize করুন
5. Netlify account তৈরি হবে

### Step 2: Site Import করুন (GitHub থেকে)
1. Netlify dashboard-এ **"Add new site"** → **"Import an existing project"** ক্লিক করুন
2. **"Deploy with GitHub"** → **"Authorize Netlify"** ক্লিক করুন
3. GitHub repository select করুন: `sonarkhata-web`
4. **"Import"** ক্লিক করুন

### Step 3: Build Settings Setup করুন
Netlify automatically detect করবে, কিন্তু verify করুন:

- **Build command:** `npm run build`
- **Publish directory:** `dist`
- **Base directory:** (খালি রাখুন)

**"Deploy site"** ক্লিক করুন

### Step 4: Wait for Deploy
1. 2-3 মিনিট wait করুন
2. ✅ **"Site is live"** message দেখবেন
3. আপনার site URL পাবেন: `https://sonarkhata-web-123.netlify.app` (random number)

---

## Part 3: Auto Deploy Setup

### Automatic Deploy:
- GitHub-এ code push করলে Netlify automatically নতুন version deploy করবে
- Build command: `npm run build`
- Publish: `dist` folder

### Deploy Settings Verify:
1. Site → **Settings** → **Build & deploy**
2. **Build command:** `npm run build`
3. **Publish directory:** `dist`
4. ✅ **"Deploy only when the `main` branch changes"** check করুন

---

## Part 4: Code Update করা

### যখন Code Update করবেন:

```bash
# Web version folder-এ যান
cd D:\sonarkhata\sonarkhata-web

# Changes add করুন
git add .

# Commit করুন
git commit -m "Updated features - custom date range"

# GitHub-এ push করুন
git push origin main
```

**Netlify automatically নতুন version deploy করবে!** (2-3 মিনিট লাগবে)

---

## Part 5: Custom Domain Setup (Optional)

### যদি আপনার নিজের Domain থাকে:

1. Netlify → Site → **Settings** → **Domain management**
2. **"Add custom domain"** ক্লিক করুন
3. আপনার domain দিন (যেমন: `sonarkhata.com`)
4. DNS settings follow করুন
5. Netlify DNS records add করুন আপনার domain provider-এ

---

## Troubleshooting (সমস্যা সমাধান)

### ❌ "git is not recognized"
**সমাধান:** 
- Git install করুন: https://git-scm.com/download/win
- Terminal restart করুন

### ❌ "npm is not recognized"
**সমাধান:** 
- Node.js install করুন: https://nodejs.org/
- Terminal restart করুন

### ❌ Build failed on Netlify
**সমাধান:**
1. Netlify → Site → **Deploys** → Failed deploy → **"View build log"**
2. Error message দেখুন
3. Local-এ test করুন: `npm run build`
4. Error fix করে আবার push করুন

### ❌ Site shows blank
**সমাধান:**
1. Netlify → Site settings → **Build & deploy**
2. Publish directory verify করুন: `dist`
3. Build command verify করুন: `npm run build`
4. Browser console check করুন (F12)

### ❌ GitHub push error
**সমাধান:**
- Personal Access Token use করুন (password-এর বদলে)
- Token-এ `repo` scope আছে verify করুন

---

## Quick Commands Summary

```bash
# First time setup
cd sonarkhata-web
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/sonarkhata-web.git
git push -u origin main

# Update code (every time)
git add .
git commit -m "Update message"
git push origin main
```

---

## Benefits

✅ **Auto Deploy:** GitHub-এ push করলেই Netlify deploy করবে
✅ **Free Hosting:** Netlify free plan-এ unlimited sites
✅ **HTTPS:** Automatic SSL certificate
✅ **Fast CDN:** Global content delivery
✅ **Custom Domain:** আপনার domain add করতে পারবেন
✅ **Version History:** প্রতিটি deploy-এর history থাকবে

---

## Important Notes

### ✅ DO:
- সবসময় `git add .` → `git commit` → `git push` sequence follow করুন
- Meaningful commit messages দিন
- Build test করুন local-এ before push

### ❌ DON'T:
- `node_modules` folder commit করবেন না (`.gitignore` আছে)
- `.env` files commit করবেন না
- Large files commit করবেন না

---

## Support

কোনো সমস্যা হলে:
1. GitHub Issues check করুন
2. Netlify build logs দেখুন
3. Browser console check করুন (F12)
4. Local build test করুন: `npm run build`

**Happy Deploying! 🚀**

