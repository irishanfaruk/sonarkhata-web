import React, { useState, useCallback, useEffect, useMemo } from 'react';
import Header from './components/Header';
import TransactionTable from './components/TransactionTable';
import AddEntryModal from './components/AddEntryModal';
import SummaryReportModal from './components/SummaryReportModal';
import Toast from './components/Toast';
import SheetTabs from './components/SheetTabs';
import PasswordPromptModal from './components/PasswordPromptModal';
import GoldCalculatorModal from './components/GoldCalculatorModal';
import SyncModal from './components/SyncModal';
import SettingsModal, { SettingsState } from './components/SettingsModal';
import { useLocalStorage } from './hooks/useLocalStorage';
import { Transaction, AppState, Sheet } from './types';
import Modal from './components/Modal';
import { exportTransactionsToSheet, importTransactionsFromSheet } from './utils/sheetSync';

// --- Start of AddSheetModal Component ---
interface AddSheetModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (name: string) => void;
}

const AddSheetModal: React.FC<AddSheetModalProps> = ({ isOpen, onClose, onSave }) => {
  const [name, setName] = useState('');

  useEffect(() => {
    if (isOpen) {
      setName('');
    }
  }, [isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onSave(name.trim());
      onClose();
    }
  };

  const labelStyle: React.CSSProperties = { display: 'block', marginBottom: '0.5rem', fontWeight: 500, color: 'var(--text-secondary-color)' };
  const inputStyle: React.CSSProperties = { width: '100%', padding: '0.7rem', border: '1px solid var(--border-color)', borderRadius: '6px', backgroundColor: 'var(--background-color)', color: 'var(--text-color)', fontSize: '1rem' };
  const buttonContainer: React.CSSProperties = { display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '1.5rem' };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Add New Sheet">
      <form onSubmit={handleSubmit}>
        <div>
          <label style={labelStyle} htmlFor="sheet-name">Sheet Name</label>
          <input
            style={inputStyle}
            type="text"
            id="sheet-name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            autoFocus
            required
          />
        </div>
        <div style={buttonContainer}>
           <button type="button" onClick={onClose} style={{padding: '0.6rem 1.2rem', border: '1px solid var(--border-color)', borderRadius: '6px', cursor: 'pointer', backgroundColor: 'transparent', color: 'var(--text-color)'}}>Cancel</button>
           <button type="submit" style={{padding: '0.6rem 1.2rem', border: 'none', borderRadius: '6px', cursor: 'pointer', backgroundColor: 'var(--primary-color)', color: '#111827', fontWeight: 'bold'}}>Save Sheet</button>
        </div>
      </form>
    </Modal>
  );
};
// --- End of AddSheetModal Component ---

// --- Start of RenameSheetModal Component ---
interface RenameSheetModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (name: string) => void;
  initialName: string;
}

const RenameSheetModal: React.FC<RenameSheetModalProps> = ({ isOpen, onClose, onSave, initialName }) => {
  const [name, setName] = useState(initialName);

  useEffect(() => {
    if (isOpen) {
      setName(initialName);
    }
  }, [isOpen, initialName]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && name.trim() !== initialName) {
      onSave(name.trim());
    }
    onClose();
  };
  
  const labelStyle: React.CSSProperties = { display: 'block', marginBottom: '0.5rem', fontWeight: 500, color: 'var(--text-secondary-color)' };
  const inputStyle: React.CSSProperties = { width: '100%', padding: '0.7rem', border: '1px solid var(--border-color)', borderRadius: '6px', backgroundColor: 'var(--background-color)', color: 'var(--text-color)', fontSize: '1rem' };
  const buttonContainer: React.CSSProperties = { display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '1.5rem' };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Rename Sheet">
      <form onSubmit={handleSubmit}>
        <div>
          <label style={labelStyle} htmlFor="sheet-name-rename">New Sheet Name</label>
          <input
            style={inputStyle}
            type="text"
            id="sheet-name-rename"
            value={name}
            onChange={(e) => setName(e.target.value)}
            autoFocus
            required
          />
        </div>
        <div style={buttonContainer}>
           <button type="button" onClick={onClose} style={{padding: '0.6rem 1.2rem', border: '1px solid var(--border-color)', borderRadius: '6px', cursor: 'pointer', backgroundColor: 'transparent', color: 'var(--text-color)'}}>Cancel</button>
           <button type="submit" style={{padding: '0.6rem 1.2rem', border: 'none', borderRadius: '6px', cursor: 'pointer', backgroundColor: 'var(--primary-color)', color: '#111827', fontWeight: 'bold'}}>Rename Sheet</button>
        </div>
      </form>
    </Modal>
  );
};
// --- End of RenameSheetModal Component ---


const initialAppState: AppState = {
  sheets: {
    'sheet-0': {
      id: 'sheet-0',
      name: 'Tab1',
      transactions: [],
    },
  },
  activeSheetId: 'sheet-0',
};

const App: React.FC = () => {
  const [appState, setAppState] = useLocalStorage<AppState>('stockKhataData', initialAppState);
  const [hasMigratedDefaultSheets, setHasMigratedDefaultSheets] = useState(false);
  const [isAddModalOpen, setAddModalOpen] = useState(false);
  const [isSummaryModalOpen, setSummaryModalOpen] = useState(false);
  const [isCalculatorModalOpen, setCalculatorModalOpen] = useState(false);
  const [calculatorInitialWeight, setCalculatorInitialWeight] = useState<{ vori: number; ana: number; roti: number; point: number } | undefined>(undefined);
  const [calculatorPriceCallback, setCalculatorPriceCallback] = useState<((price: number) => void) | null>(null);
  const [isAddSheetModalOpen, setAddSheetModalOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  
  const [isPasswordModalOpen, setPasswordModalOpen] = useState(false);
  const [pendingAction, setPendingAction] = useState<{ action: () => void; title: string } | null>(null);
  const [renamingSheetInfo, setRenamingSheetInfo] = useState<{ id: string; name: string } | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isSyncModalOpen, setSyncModalOpen] = useState(false);
  const [isSettingsOpen, setSettingsOpen] = useState(false);

  const [settings, setSettings] = useLocalStorage<SettingsState>('sonarkhatSettings', {
    theme: 'light',
    sheetApiUrl: '',
    dataFolderPath: null,
    shopName: 'Sonarkhata',
    adminUsername: 'admin',
    adminPassword: 'admin123',
  });
  const [hasLoadedSettingsFromFile, setHasLoadedSettingsFromFile] = useState(false);

  useEffect(() => {
    const body = document.body;
    if (settings.theme === 'dark') {
      body.classList.add('theme-dark');
    } else {
      body.classList.remove('theme-dark');
    }
  }, [settings.theme]);

  // One-time migration: if the user still has the old default A–H sheets and
  // only one of them contains data, collapse into a single `Tab1` sheet.
  useEffect(() => {
    if (hasMigratedDefaultSheets) return;

    const sheetEntries = Object.entries(appState.sheets);
    if (!sheetEntries.length) return;

    const allAreSingleLetter = sheetEntries.every(([, sheet]) =>
      /^[A-H]$/.test(sheet.name)
    );

    if (!allAreSingleLetter) {
      setHasMigratedDefaultSheets(true);
      return;
    }

    const nonEmpty = sheetEntries.filter(([, sheet]) => sheet.transactions.length > 0);

    // If multiple sheets actually have data, don't risk deleting anything.
    if (nonEmpty.length !== 1) {
      setHasMigratedDefaultSheets(true);
      return;
    }

    const [, usedSheet] = nonEmpty[0];
    const newId = 'sheet-0';

    const migrated: AppState = {
      sheets: {
        [newId]: {
          ...usedSheet,
          id: newId,
          name: 'Tab1',
        },
      },
      activeSheetId: newId,
    };

    setAppState(migrated);
    setHasMigratedDefaultSheets(true);
  }, [appState.sheets, hasMigratedDefaultSheets, setAppState]);

  useEffect(() => {
    if (settings.shopName && settings.shopName.trim().length > 0) {
      document.title = settings.shopName.trim();
    } else {
      document.title = 'Sonarkhata';
    }
  }, [settings.shopName]);

  // If a custom folder is selected, mirror appState to a JSON file there
  // and try to restore from it on startup.
  useEffect(() => {
    const anyWindow: any = window;
    const api = anyWindow.electronAPI;
    if (!api || !settings.dataFolderPath) return;

    if (!hasLoadedSettingsFromFile) {
      (async () => {
        try {
          const loadedSettings = await api.loadSettings(settings.dataFolderPath);
          if (loadedSettings && typeof loadedSettings === 'object') {
            setSettings(prev => ({ ...prev, ...loadedSettings }));
          }
        } catch (e) {
          console.error('Failed to load settings file', e);
        } finally {
          setHasLoadedSettingsFromFile(true);
        }
      })();
    }

    let cancelled = false;
    (async () => {
      try {
        const data = await api.loadData(settings.dataFolderPath);
        if (!cancelled && data && data.sheets && data.activeSheetId) {
          setAppState(data as AppState);
        }
      } catch (e) {
        console.error('Failed to load data file', e);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [settings.dataFolderPath, setAppState, setSettings, hasLoadedSettingsFromFile]);

  useEffect(() => {
    const anyWindow: any = window;
    const api = anyWindow.electronAPI;
    if (!api || !settings.dataFolderPath) return;
    api
      .saveData(settings.dataFolderPath, appState)
      .catch((e: unknown) => console.error('Failed to save data file', e));
  }, [settings.dataFolderPath, appState]);

  useEffect(() => {
    const anyWindow: any = window;
    const api = anyWindow.electronAPI;
    if (!api || !settings.dataFolderPath) return;
    api
      .saveSettings(settings.dataFolderPath, settings)
      .catch((e: unknown) => console.error('Failed to save settings file', e));
  }, [settings.dataFolderPath, settings]);

  const updateSettings = (partial: Partial<SettingsState>) => {
    setSettings(prev => ({ ...prev, ...partial }));
  };

  const activeSheet = appState.sheets[appState.activeSheetId];
  const transactions = activeSheet ? activeSheet.transactions : [];

  const filteredTransactions = useMemo(() => transactions.filter(t =>
    !searchQuery || (t.tokenNumber && t.tokenNumber.toLowerCase().includes(searchQuery.toLowerCase()))
  ), [transactions, searchQuery]);

  const showToast = (message: string, type: 'success' | 'error') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };
  
  const setActiveSheetId = (id: string) => {
    setAppState(prev => ({...prev, activeSheetId: id}));
  };

  const addSheet = (name: string) => {
    const newId = `sheet-${Date.now()}`;
    setAppState(prev => ({
      ...prev,
      sheets: {
        ...prev.sheets,
        [newId]: { id: newId, name, transactions: [] }
      },
      activeSheetId: newId
    }));
    showToast(`Sheet "${name}" created.`, 'success');
  };

  const renameSheet = (id: string, newName: string) => {
    setAppState(prev => {
      const newSheets = { ...prev.sheets };
      if (newSheets[id]) {
        newSheets[id] = { ...newSheets[id], name: newName };
      }
      return { ...prev, sheets: newSheets };
    });
    showToast('Sheet renamed.', 'success');
  };

  const handleStartRenameSheet = (id: string, name: string) => {
    setRenamingSheetInfo({ id, name });
  };
  
  const handleRenameSheet = (newName: string) => {
    if (renamingSheetInfo) {
      renameSheet(renamingSheetInfo.id, newName);
      setRenamingSheetInfo(null);
    }
  };

  const deleteSheet = (id: string) => {
    if (Object.keys(appState.sheets).length <= 1) {
      showToast('Cannot delete the last sheet.', 'error');
      return;
    }
    
    setPendingAction({
        title: `Confirm Deletion of Sheet "${appState.sheets[id].name}"`,
        action: () => {
            setAppState(prev => {
                const newSheets = { ...prev.sheets };
                delete newSheets[id];
                const newActiveId = prev.activeSheetId === id ? Object.keys(newSheets)[0] : prev.activeSheetId;
                return { activeSheetId: newActiveId, sheets: newSheets };
            });
            showToast('Sheet deleted.', 'success');
        }
    });
    setPasswordModalOpen(true);
  };

  const handleAddOrUpdateTransaction = (entry: Omit<Transaction, 'id' | 'profit'> & { id?: string }) => {
    if (entry.tokenNumber) {
      const isDuplicate = transactions.some(
        (t) => t.tokenNumber && t.tokenNumber === entry.tokenNumber && t.id !== entry.id
      );
      if (isDuplicate) {
        showToast('Error: Token Number must be unique within this sheet.', 'error');
        return;
      }
    }

    const purchasePrice = entry.purchasePrice || 0;
    const salePrice = entry.salePrice || 0;

    let profit: number | null = null;
    if (purchasePrice > 0 && salePrice > 0) {
        profit = salePrice - purchasePrice;
    }
    
    setAppState(prev => {
      const newSheets = { ...prev.sheets };
      const currentSheet = newSheets[prev.activeSheetId];
      let updatedTransactions: Transaction[];

      if (entry.id) { // Update existing
        updatedTransactions = currentSheet.transactions.map(t => t.id === entry.id ? { ...t, ...entry, profit } as Transaction : t);
        showToast('Transaction updated successfully!', 'success');
      } else { // Add new
        const newTransaction: Transaction = {
          ...entry,
          id: new Date().toISOString(),
          profit,
        };
        updatedTransactions = [...currentSheet.transactions, newTransaction];
        showToast('New entry added successfully!', 'success');
      }

      newSheets[prev.activeSheetId] = { ...currentSheet, transactions: updatedTransactions };
      return { ...prev, sheets: newSheets };
    });

    setAddModalOpen(false);
    setEditingTransaction(null);
  };

  const handleExportToCloud = useCallback(async () => {
    if (!settings.sheetApiUrl || !settings.sheetApiUrl.trim()) {
      showToast('Please set the Google Apps Script URL in Settings.', 'error');
      return;
    }

    const sheets = appState.sheets;
    const totalRows = Object.values(sheets).reduce(
      (sum, sheet) => sum + sheet.transactions.length,
      0
    );

    if (totalRows === 0) {
      showToast('No rows to export in any sheet.', 'error');
      return;
    }

    setIsSyncing(true);
    try {
      await exportTransactionsToSheet(
        sheets,
        settings.sheetApiUrl,
        (message) => showToast(message, 'success')
      );
      showToast('All tabs exported successfully.', 'success');
    } catch (error) {
      console.error('Export to Google Sheet failed', error);
      showToast('Export failed. Please check your internet.', 'error');
    } finally {
      setIsSyncing(false);
      setSyncModalOpen(false);
    }
  }, [appState.sheets, settings.sheetApiUrl]);

  const handleImportFromCloud = useCallback(async () => {
    if (!activeSheet) {
      showToast('No active sheet selected for import.', 'error');
      return;
    }
    if (!settings.sheetApiUrl || !settings.sheetApiUrl.trim()) {
      showToast('Please set the Google Apps Script URL in Settings.', 'error');
      return;
    }

    setIsSyncing(true);
    try {
      const imported = await importTransactionsFromSheet(
        activeSheet.name,
        settings.sheetApiUrl
      );
      setAppState(prev => {
        const sheets = { ...prev.sheets };
        const current = sheets[prev.activeSheetId];
        const updatedSheet: Sheet = {
          ...current,
          transactions: imported,
        };
        return {
          ...prev,
          sheets: {
            ...sheets,
            [prev.activeSheetId]: updatedSheet,
          },
        };
      });
      showToast(`Data imported into "${activeSheet.name}" successfully.`, 'success');
    } catch (error) {
      console.error('Import from Google Sheet failed', error);
      showToast('Import failed. Please check your internet.', 'error');
    } finally {
      setIsSyncing(false);
      setSyncModalOpen(false);
    }
  }, [setAppState, settings.sheetApiUrl, activeSheet]);

  const handleOpenAddModal = () => {
    setEditingTransaction(null);
    setAddModalOpen(true);
  };

  const handleEditTransaction = (transaction: Transaction) => {
    setEditingTransaction(transaction);
    setAddModalOpen(true);
  };
  
  const handleDuplicateTransaction = (transaction: Transaction) => {
    const duplicatedTransaction: Transaction = {
        ...transaction,
        id: '', 
        purchaseDate: new Date().toISOString().split('T')[0],
        saleDate: null,
        salePrice: null,
        tokenNumber: '',
        profit: null,
        isSoldManually: false,
    };
    setEditingTransaction(duplicatedTransaction);
    setAddModalOpen(true);
  };

  const handleDeleteTransaction = (id: string) => {
    setPendingAction({
      title: 'Admin Authentication Required',
      action: () => {
        setAppState(prev => {
          const newSheets = { ...prev.sheets };
          const currentSheet = newSheets[prev.activeSheetId];
          const updatedTransactions = currentSheet.transactions.filter(t => t.id !== id);
          newSheets[prev.activeSheetId] = { ...currentSheet, transactions: updatedTransactions };
          return { ...prev, sheets: newSheets };
        });
        showToast('Transaction deleted.', 'success');
      }
    });
    setPasswordModalOpen(true);
  };

  const handleBulkDeleteTransactions = (ids: string[]) => {
    if (!ids.length) return;
    setPendingAction({
      title: `Admin Authentication Required (${ids.length} items)`,
      action: () => {
        setAppState(prev => {
          const newSheets = { ...prev.sheets };
          const currentSheet = newSheets[prev.activeSheetId];
          const idSet = new Set(ids);
          const updatedTransactions = currentSheet.transactions.filter(t => !idSet.has(t.id));
          newSheets[prev.activeSheetId] = { ...currentSheet, transactions: updatedTransactions };
          return { ...prev, sheets: newSheets };
        });
        showToast('Selected transactions deleted.', 'success');
      }
    });
    setPasswordModalOpen(true);
  };
  
  const handleAuthConfirm = (username: string, password: string) => {
    const expectedUser = (settings.adminUsername || 'admin').toLowerCase();
    const expectedPass = settings.adminPassword || 'admin123';

    if (username.toLowerCase() === expectedUser && password === expectedPass) {
      pendingAction?.action();
      showToast('Action Confirmed!', 'success');
    } else {
      showToast('Incorrect username or password.', 'error');
    }
    setPasswordModalOpen(false);
    setPendingAction(null);
  };


  const handleCloseModal = () => {
    setAddModalOpen(false);
    setEditingTransaction(null);
  };

  const handleOpenCalculatorFromEntry = (weight: { vori: number; ana: number; roti: number; point: number }, targetField: 'purchasePrice' | 'salePrice', onPriceCalculated: (price: number) => void) => {
    setCalculatorInitialWeight(weight);
    setCalculatorPriceCallback(() => onPriceCalculated);
    setCalculatorModalOpen(true);
  };

  const handlePriceCalculated = (price: number) => {
    if (calculatorPriceCallback) {
      calculatorPriceCallback(price);
    }
    setCalculatorPriceCallback(null);
    setCalculatorInitialWeight(undefined);
    setCalculatorModalOpen(false);
  };

  return (
    <div className="app-shell" style={{ maxWidth: '1280px', margin: '0 auto' }}>
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
      
      <Header
        onAddEntryClick={handleOpenAddModal}
        onSummaryReportClick={() => setSummaryModalOpen(true)}
        onCalculatorClick={() => setCalculatorModalOpen(true)}
        onSyncClick={() => setSyncModalOpen(true)}
        onSettingsClick={() => setSettingsOpen(true)}
        shopName={settings.shopName || 'Sonarkhata'}
        isSyncing={isSyncing}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />
      
      <SheetTabs 
        sheets={appState.sheets}
        activeSheetId={appState.activeSheetId}
        onSelectSheet={setActiveSheetId}
        onAddSheetClick={() => setAddSheetModalOpen(true)}
        onRenameSheetClick={handleStartRenameSheet}
        onDeleteSheet={deleteSheet}
      />
      
      <main className="printable-area" style={{ marginTop: '1.5rem', backgroundColor: 'var(--card-background)', borderRadius: '16px', boxShadow: '0 10px 30px rgba(0,0,0,0.1), 0 0 0 1px rgba(0,0,0,0.05)', padding: '2rem', border: '1px solid rgba(0,0,0,0.05)' }}>
        <div className="print-header">
          <h1>{settings.shopName || 'Sonarkhata'}</h1>
            <h2>Sheet: {activeSheet?.name || ''}</h2>
            <p>Report Date: {new Date().toLocaleDateString('en-GB')}</p>
        </div>
        <TransactionTable
          transactions={filteredTransactions}
          allTransactionsForPrinting={transactions}
          onEdit={handleEditTransaction}
          onDelete={handleDeleteTransaction}
          onDuplicate={handleDuplicateTransaction}
          onNotify={showToast}
          onBulkDelete={handleBulkDeleteTransactions}
        />
      </main>

      {isAddModalOpen && (
        <AddEntryModal
          isOpen={isAddModalOpen}
          onClose={handleCloseModal}
          onSave={handleAddOrUpdateTransaction}
          existingTransaction={editingTransaction}
          onOpenCalculator={handleOpenCalculatorFromEntry}
        />
      )}

      {isSummaryModalOpen && (
        <div className="summary-report-print-container">
          <SummaryReportModal
            isOpen={isSummaryModalOpen}
            onClose={() => setSummaryModalOpen(false)}
            transactions={transactions}
            sheetName={activeSheet?.name || ''}
            appTitle={settings.shopName || 'Sonarkhata'}
            onNotify={showToast}
          />
        </div>
      )}
      
      {isCalculatorModalOpen && (
        <GoldCalculatorModal 
          isOpen={isCalculatorModalOpen}
          onClose={() => {
            setCalculatorModalOpen(false);
            setCalculatorPriceCallback(null);
            setCalculatorInitialWeight(undefined);
          }}
          onPriceCalculated={calculatorPriceCallback ? handlePriceCalculated : undefined}
          initialWeight={calculatorInitialWeight}
        />
      )}

      {isSyncModalOpen && (
        <SyncModal
          isOpen={isSyncModalOpen}
          onClose={() => setSyncModalOpen(false)}
          onExport={handleExportToCloud}
          onImport={handleImportFromCloud}
          isBusy={isSyncing}
        />
      )}

      {isSettingsOpen && (
        <SettingsModal
          isOpen={isSettingsOpen}
          onClose={() => setSettingsOpen(false)}
          settings={settings}
          onChange={updateSettings}
        />
      )}

      {isAddSheetModalOpen && (
        <AddSheetModal
          isOpen={isAddSheetModalOpen}
          onClose={() => setAddSheetModalOpen(false)}
          onSave={addSheet}
        />
      )}

      {renamingSheetInfo && (
        <RenameSheetModal
          isOpen={!!renamingSheetInfo}
          onClose={() => setRenamingSheetInfo(null)}
          onSave={handleRenameSheet}
          initialName={renamingSheetInfo.name}
        />
      )}

      {isPasswordModalOpen && pendingAction && (
          <PasswordPromptModal
            isOpen={isPasswordModalOpen}
            onClose={() => {
                setPasswordModalOpen(false);
                setPendingAction(null);
            }}
            onConfirm={handleAuthConfirm}
            title={pendingAction.title}
          />
      )}
    </div>
  );
};

export default App;
