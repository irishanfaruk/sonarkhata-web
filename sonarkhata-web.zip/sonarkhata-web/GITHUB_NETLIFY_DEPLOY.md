# GitHub + Netlify Deployment Guide (Step by Step)

## সম্পূর্ণ Step-by-Step Guide

### Part 1: GitHub-এ Code Upload করা

#### Step 1: GitHub Account তৈরি করুন (যদি না থাকে)
1. https://github.com এ যান
2. "Sign up" ক্লিক করুন
3. Account তৈরি করুন

#### Step 2: নতুন Repository তৈরি করুন
1. GitHub-এ login করুন
2. Right side-এ "+" icon → "New repository" ক্লিক করুন
3. Repository name দিন: `sonarkhata-web` (বা আপনার পছন্দমতো)
4. Description (optional): "Sonarkhata - Gold Inventory Management Web App"
5. **Public** select করুন (Netlify free plan-এর জন্য)
6. ✅ "Add a README file" **UNCHECK** করুন (আমাদের code আছে)
7. "Create repository" ক্লিক করুন

#### Step 3: Git Install করুন (যদি না থাকে)
1. https://git-scm.com/download/win এ যান
2. Download করুন এবং install করুন
3. Install করার সময় default options select করুন

#### Step 4: Code GitHub-এ Push করুন

**Terminal/Command Prompt খুলুন:**

```bash
# Web version folder-এ যান
cd D:\sonarkhata\sonarkhata-web

# Git initialize করুন
git init

# সব files add করুন
git add .

# First commit করুন
git commit -m "Initial commit - Sonarkhata Web Version"

# GitHub repository-এর URL add করুন
# (আপনার GitHub username এবং repository name use করুন)
git remote add origin https://github.com/YOUR_USERNAME/sonarkhata-web.git

# Code push করুন
git branch -M main
git push -u origin main
```

**Note:** প্রথমবার push করলে GitHub username এবং password/token চাইবে।

#### Step 5: GitHub Personal Access Token তৈরি করুন (যদি password কাজ না করে)

1. GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)
2. "Generate new token" → "Generate new token (classic)"
3. Note: "Netlify Deploy"
4. Expiration: 90 days (বা আপনার পছন্দ)
5. Scopes: ✅ `repo` (full control) check করুন
6. "Generate token" ক্লিক করুন
7. Token copy করুন (একবারই দেখবেন!)
8. Terminal-এ password-এর জায়গায় এই token paste করুন

---

### Part 2: Netlify-এ Deploy করা

#### Method 1: GitHub থেকে Auto Deploy (Recommended)

##### Step 1: Netlify Account তৈরি করুন
1. https://www.netlify.com এ যান
2. "Sign up" → "GitHub" select করুন
3. GitHub account দিয়ে login করুন

##### Step 2: Site Import করুন
1. Netlify dashboard-এ "Add new site" → "Import an existing project" ক্লিক করুন
2. "Deploy with GitHub" → "Authorize Netlify" ক্লিক করুন
3. GitHub repository select করুন: `sonarkhata-web`
4. "Import" ক্লিক করুন

##### Step 3: Build Settings Setup করুন
Netlify automatically detect করবে, কিন্তু verify করুন:

- **Build command:** `npm run build`
- **Publish directory:** `dist`
- **Base directory:** (খালি রাখুন)

##### Step 4: Deploy করুন
1. "Deploy site" ক্লিক করুন
2. 2-3 মিনিট wait করুন
3. ✅ "Site is live" message দেখবেন
4. আপনার site URL পাবেন: `https://sonarkhata-web-123.netlify.app` (random number)

##### Step 5: Custom Domain Setup (Optional)
1. Site settings → Domain management
2. "Add custom domain" → আপনার domain দিন
3. DNS settings follow করুন

---

#### Method 2: Manual Deploy (Drag & Drop)

##### Step 1: Build করুন
```bash
cd D:\sonarkhata\sonarkhata-web
npm install
npm run build
```

##### Step 2: Netlify Drop
1. https://app.netlify.com/drop এ যান
2. `sonarkhata-web/dist` folder drag & drop করুন
3. Automatic deploy হবে
4. URL পাবেন

**Note:** Manual deploy-এ auto-update হবে না। প্রতিবার code change হলে আবার build করে drag & drop করতে হবে।

---

### Part 3: Auto Deploy Setup (GitHub থেকে)

#### Automatic Deploy:
- GitHub-এ code push করলে Netlify automatically নতুন version deploy করবে
- Build command: `npm run build`
- Publish: `dist` folder

#### Deploy Settings:
1. Site settings → Build & deploy
2. Build command: `npm run build`
3. Publish directory: `dist`
4. ✅ "Deploy only when the `main` branch changes" check করুন

---

### Part 4: Code Update করা

#### যখন Code Update করবেন:

```bash
# Web version folder-এ যান
cd D:\sonarkhata\sonarkhata-web

# Changes add করুন
git add .

# Commit করুন
git commit -m "Updated features"

# GitHub-এ push করুন
git push origin main
```

**Netlify automatically নতুন version deploy করবে!**

---

## Troubleshooting

### ❌ "git is not recognized"
**সমাধান:** Git install করুন: https://git-scm.com/download/win

### ❌ "npm is not recognized"
**সমাধান:** Node.js install করুন: https://nodejs.org/

### ❌ Build failed on Netlify
**সমাধান:**
1. Netlify → Site → Deploys → Failed deploy → "View build log"
2. Error message দেখুন
3. Local-এ test করুন: `npm run build`
4. Error fix করে আবার push করুন

### ❌ Site shows blank
**সমাধান:**
1. Netlify → Site settings → Build & deploy
2. Publish directory verify করুন: `dist`
3. Build command verify করুন: `npm run build`

---

## Quick Commands Summary

```bash
# First time setup
cd sonarkhata-web
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/sonarkhata-web.git
git push -u origin main

# Update code
git add .
git commit -m "Update message"
git push origin main
```

---

## Benefits

✅ **Auto Deploy:** GitHub-এ push করলেই Netlify deploy করবে
✅ **Free Hosting:** Netlify free plan-এ unlimited sites
✅ **HTTPS:** Automatic SSL certificate
✅ **Fast CDN:** Global content delivery
✅ **Custom Domain:** আপনার domain add করতে পারবেন

---

## Support

কোনো সমস্যা হলে:
1. GitHub Issues check করুন
2. Netlify build logs দেখুন
3. Browser console check করুন (F12)

**Happy Deploying! 🚀**

