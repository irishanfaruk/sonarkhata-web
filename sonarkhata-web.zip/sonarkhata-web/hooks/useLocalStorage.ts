import { useState, useEffect, Dispatch, SetStateAction } from 'react';

function getStorageValue<T>(key: string, defaultValue: T): T {
  const saved = localStorage.getItem(key);
  if (saved) {
    try {
        return JSON.parse(saved);
    } catch (e) {
        console.error('Failed to parse localStorage value', e);
        return defaultValue;
    }
  }
  return defaultValue;
}

// FIX: Correctly type the return value of useLocalStorage hook to avoid 'React' namespace error.
export const useLocalStorage = <T>(key: string, defaultValue: T): [T, Dispatch<SetStateAction<T>>] => {
  const [value, setValue] = useState(() => {
    return getStorageValue(key, defaultValue);
  });

  useEffect(() => {
    localStorage.setItem(key, JSON.stringify(value));
  }, [key, value]);

  return [value, setValue];
};
