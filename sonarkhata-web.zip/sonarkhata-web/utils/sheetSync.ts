import { Transaction, Weight, Sheet } from '../types';

const SHEET_API_URL = import.meta.env.VITE_SHEET_WEB_APP_URL || '';

const resolveSheetApiUrl = (override?: string): string => {
  const url = override?.trim() || SHEET_API_URL;
  if (!url) {
    throw new Error('Sheet API URL is not configured. Please set it in Settings.');
  }
  return url;
};

const formatWeight = (weight: Weight | null) => {
  if (!weight) return '';
  const parts: string[] = [];
  if (weight.vori) parts.push(`${weight.vori} Vori`);
  if (weight.ana) parts.push(`${weight.ana} Ana`);
  if (weight.roti) parts.push(`${weight.roti} Roti`);
  if (weight.point) parts.push(`${weight.point} Point`);
  return parts.join(', ');
};

const deriveStatus = (transaction: Transaction) => {
  if (transaction.saleDate || transaction.isSoldManually) {
    return 'Sold';
  }
  return 'In Stock';
};

// --- EXPORT HELPERS ---

export const syncTransactionToSheet = async (
  transaction: Transaction,
  sheetName: string,
  apiUrlOverride?: string
) => {
  const url = resolveSheetApiUrl(apiUrlOverride);

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      product: transaction.product,
      sheetName,
      purchaseDate: transaction.purchaseDate || '',
      saleDate: transaction.saleDate || '',
      token: transaction.tokenNumber || '',
      weight: formatWeight(transaction.weight),
      purchasePrice: transaction.purchasePrice ?? '',
      salePrice: transaction.salePrice ?? '',
      profit: transaction.profit ?? '',
      comment: transaction.comment || '',
      status: deriveStatus(transaction),
    }),
  });

  if (!response.ok) {
    throw new Error('Failed to sync transaction');
  }
};

export const exportTransactionsToSheet = async (
  sheets: { [id: string]: Sheet },
  apiUrlOverride?: string,
  onProgress?: (message: string) => void
): Promise<void> => {
  const url = resolveSheetApiUrl(apiUrlOverride);
  const sheetList = Object.values(sheets);

  for (const sheet of sheetList) {
    if (!sheet.transactions.length) continue;
    if (onProgress) {
      onProgress(`Exporting ${sheet.name}...`);
    }
    for (const tx of sheet.transactions) {
      // Export row‑by‑row as required by the Apps Script Web App.
      // If a single row fails we throw, so the caller can show an error toast.
      await syncTransactionToSheet(tx, sheet.name, url);
    }
  }
};

// --- IMPORT HELPERS ---

type SheetRow = {
  product?: string;
  purchaseDate?: string;
  saleDate?: string;
  token?: string;
  weight?: string;
  purchasePrice?: number | string;
  salePrice?: number | string;
  profit?: number | string;
  comment?: string;
  status?: string;
};

const parseDateToISO = (value?: string | null): string | null => {
  if (!value) return null;

  // Try direct Date parsing (handles ISO like 2023-11-25T00:00:00.000Z)
  const direct = new Date(value);
  if (!Number.isNaN(direct.getTime())) {
    return direct.toISOString().split('T')[0];
  }

  // Try dd/mm/yyyy
  const ddmmyyyy = value.split(/[\/\-]/);
  if (ddmmyyyy.length === 3) {
    const [d, m, y] = ddmmyyyy.map((p) => parseInt(p, 10));
    if (!Number.isNaN(d) && !Number.isNaN(m) && !Number.isNaN(y)) {
      const fromParts = new Date(y, m - 1, d);
      if (!Number.isNaN(fromParts.getTime())) {
        return fromParts.toISOString().split('T')[0];
      }
    }
  }

  return null;
};

const parseNumber = (value?: number | string | null): number | null => {
  if (value === undefined || value === null || value === '') return null;
  const n = typeof value === 'number' ? value : parseFloat(value);
  return Number.isNaN(n) ? null : n;
};

const parseWeightString = (weight?: string): { weight: Weight | null; total: number | null } => {
  if (!weight) return { weight: null, total: null };

  const w: Weight = { vori: 0, ana: 0, roti: 0, point: 0 };

  const matchUnit = (label: string) => {
    const regex = new RegExp(`(\\d+(?:\\.\\d+)?)\\s*${label}`, 'i');
    const match = weight.match(regex);
    return match ? parseFloat(match[1]) : 0;
  };

  w.vori = matchUnit('vori');
  w.ana = matchUnit('ana');
  w.roti = matchUnit('roti');
  w.point = matchUnit('point');

  const total =
    w.vori + w.ana / 16 + w.roti / 96 + w.point / 960;

  if (!total) {
    return { weight: null, total: null };
  }

  return { weight: w, total };
};

export const importTransactionsFromSheet = async (
  sheetName: string,
  apiUrlOverride?: string
): Promise<Transaction[]> => {
  const baseUrl = resolveSheetApiUrl(apiUrlOverride);
  const url = `${baseUrl}?sheetName=${encodeURIComponent(sheetName)}`;

  const response = await fetch(url, { method: 'GET' });

  if (!response.ok) {
    throw new Error('Failed to fetch data from sheet');
  }

  const rows: SheetRow[] = await response.json();

  if (!Array.isArray(rows)) {
    throw new Error('Unexpected response format from sheet');
  }

  const now = new Date();

  return rows.map((row, index) => {
    const purchaseDateISO = parseDateToISO(row.purchaseDate) || now.toISOString().split('T')[0];
    const saleDateISO = parseDateToISO(row.saleDate);

    const { weight, total } = parseWeightString(row.weight);

    const purchasePrice = parseNumber(row.purchasePrice);
    const salePrice = parseNumber(row.salePrice);
    const profit = parseNumber(row.profit);

    const status = (row.status || '').toLowerCase();
    const isSold =
      status.includes('sold') ||
      (!!saleDateISO && !status.includes('stock'));

    return {
      id: `${now.toISOString()}-${index}`,
      product: row.product || 'Unknown Product',
      purchaseDate: purchaseDateISO,
      saleDate: saleDateISO,
      tokenNumber: row.token || null,
      weight,
      totalWeightInVori: total,
      purchasePrice,
      salePrice,
      profit,
      comment: row.comment || null,
      isSoldManually: isSold && !saleDateISO ? true : undefined,
    } as Transaction;
  });
};

