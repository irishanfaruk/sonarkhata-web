import React, { useState } from 'react';
import { Transaction, Weight } from '../types';

interface TransactionTableProps {
  transactions: Transaction[];
  allTransactionsForPrinting: Transaction[];
  onEdit: (transaction: Transaction) => void;
  onDelete: (id: string) => void;
  onDuplicate: (transaction: Transaction) => void;
  onNotify: (message: string, type: 'success' | 'error') => void;
  onBulkDelete: (ids: string[]) => void;
}

const ITEMS_PER_PAGE = 25;

type PdfExportResult = {
  canceled?: boolean;
  filePath?: string;
  error?: string;
};

const TransactionTable: React.FC<TransactionTableProps> = ({ transactions, onEdit, onDelete, onDuplicate, allTransactionsForPrinting, onNotify, onBulkDelete }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const electronAPI = typeof window !== 'undefined' ? (window as any).electronAPI : undefined;
  
  const getTokenNumberValue = (t: Transaction): number => {
    if (!t.tokenNumber) return Number.NaN;
    const match = t.tokenNumber.match(/\d+/);
    if (!match) return Number.NaN;
    const n = parseInt(match[0], 10);
    return Number.isNaN(n) ? Number.NaN : n;
  };

  const compareByTokenThenDate = (a: Transaction, b: Transaction): number => {
    const ta = getTokenNumberValue(a);
    const tb = getTokenNumberValue(b);
    const aHas = !Number.isNaN(ta);
    const bHas = !Number.isNaN(tb);

    if (aHas && bHas && ta !== tb) {
      return ta - tb;
    }
    if (aHas !== bHas) {
      // Rows with numeric token numbers come first
      return aHas ? -1 : 1;
    }

    // Fallback: purchaseDate, then id
    if (a.purchaseDate && b.purchaseDate && a.purchaseDate !== b.purchaseDate) {
      return a.purchaseDate.localeCompare(b.purchaseDate);
    }
    return a.id.localeCompare(b.id);
  };

  // `transactions` is the potentially filtered list for on-screen display.
  const sortedDisplayTransactions = [...transactions].sort(compareByTokenThenDate);

  // `allTransactionsForPrinting` is the complete, unfiltered list for printing.
  const sortedPrintTransactions = [...allTransactionsForPrinting].sort(compareByTokenThenDate);
  const selectedPrintTransactions = sortedPrintTransactions.filter(t => selectedIds.has(t.id));
  
  // Pagination is based on the displayed (filtered) transactions.
  const totalPages = Math.max(1, Math.ceil(sortedDisplayTransactions.length / ITEMS_PER_PAGE));
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const endIndex = startIndex + ITEMS_PER_PAGE;
  const currentTransactions = sortedDisplayTransactions.slice(startIndex, endIndex);

  const handleSelectOne = (id: string) => {
    const newSet = new Set(selectedIds);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setSelectedIds(newSet);
  };

  const handleSelectAll = () => {
    // Select all should apply to the currently displayed (filtered) items
    if (selectedIds.size === sortedDisplayTransactions.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(sortedDisplayTransactions.map(t => t.id)));
    }
  };

  const handleBulkDeleteClick = () => {
    if (selectedIds.size === 0) return;
    onBulkDelete(Array.from(selectedIds));
    setSelectedIds(new Set());
  };


  const formatCurrency = (amount: number | null) => {
    if (amount === null || isNaN(amount) || amount === 0) return '৳ 0.00';
    return `৳ ${amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const formatWeight = (weight: Weight | null): string => {
    if (!weight) return '—';
    const parts = [];
    if (weight.vori > 0) parts.push(`${weight.vori} Vori`);
    if (weight.ana > 0) parts.push(`${weight.ana} Ana`);
    if (weight.roti > 0) parts.push(`${weight.roti} Roti`);
    if (weight.point > 0) parts.push(`${weight.point} Point`);
    return parts.length > 0 ? parts.join(', ') : '—';
  };
  
  const formatDate = (dateString: string | null) => {
    if (!dateString) return '—';
    return new Date(dateString).toLocaleDateString('en-GB'); // dd/mm/yyyy
  };

  const determineStatus = (t: Transaction) => (t.saleDate || t.isSoldManually ? 'Sold' : 'In Stock');

  const summarizeRows = (rows: Transaction[]) => {
    const soldRows = rows.filter(t => determineStatus(t) === 'Sold');
    const inStockRows = rows.filter(t => determineStatus(t) === 'In Stock');
    const sumWeight = (list: Transaction[]) =>
      list.reduce((sum, t) => sum + (t.totalWeightInVori || 0), 0);

    return {
      inStockCount: inStockRows.length,
      soldCount: soldRows.length,
      inStockPurchaseValue: inStockRows.reduce((sum, t) => sum + (t.purchasePrice || 0), 0),
      soldSalesValue: soldRows.reduce((sum, t) => sum + (t.salePrice || 0), 0),
      soldProfitValue: soldRows.reduce((sum, t) => sum + (t.profit || 0), 0),
      inStockWeight: sumWeight(inStockRows),
      soldWeight: sumWeight(soldRows),
    };
  };

  const screenSummary = summarizeRows(sortedDisplayTransactions);
  const fullPrintSummary = summarizeRows(sortedPrintTransactions);
  const selectedPrintSummary = summarizeRows(selectedPrintTransactions);

  const runWithSelectionContext = <T,>(onlySelected: boolean, action: () => Promise<T> | T, cleanupDelay = 0) => {
    if (!onlySelected) {
      return action();
    }
    document.body.classList.add('printing-selected');
    const cleanup = () => document.body.classList.remove('printing-selected');
    const result = action();
    if (result && typeof (result as Promise<T>).finally === 'function') {
      return (result as Promise<T>).finally(cleanup);
    }
    window.setTimeout(cleanup, cleanupDelay);
    return result;
  };

  const handlePrintAll = () => {
    window.print();
  };

  const handlePrintSelected = () => {
    if (selectedIds.size === 0) return;
    runWithSelectionContext(true, () => window.print(), 500);
  };

  const handleSavePdf = async (onlySelected: boolean) => {
    if (!electronAPI?.savePdf) {
      onNotify('PDF export is only available in the desktop app. Use the print dialog to save as PDF in a browser.', 'error');
      return;
    }
    try {
      const result = await runWithSelectionContext<PdfExportResult>(onlySelected, () => electronAPI.savePdf());
      if (!result) {
        return;
      }
      if (result.error) {
        onNotify(`Failed to save PDF: ${result.error}`, 'error');
        return;
      }
      if (result.canceled) {
        return;
      }
      onNotify(result.filePath ? `PDF saved to ${result.filePath}` : 'PDF saved successfully.', 'success');
    } catch (error) {
      console.error('Failed to save PDF', error);
      onNotify('Failed to save PDF. Please try again.', 'error');
    }
  };
  
  const tableStyles: React.CSSProperties = {
    width: '100%',
    borderCollapse: 'collapse',
    marginTop: '1rem',
    fontSize: '0.9rem',
  };
  const thStyles: React.CSSProperties = {
    padding: '12px 15px',
    textAlign: 'left',
    borderBottom: '2px solid var(--border-color)',
    fontWeight: 600,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    color: 'var(--text-color)',
  };
  const tdStyles: React.CSSProperties = {
    padding: '12px 15px',
    borderBottom: '1px solid var(--border-color)',
    position: 'relative',
  };
  const buttonStyles: React.CSSProperties = {
    padding: '0.25rem 0.5rem',
    border: 'none',
    borderRadius: '4px',
    fontSize: '0.8rem',
    cursor: 'pointer',
    marginRight: '0.5rem',
    fontWeight: 500
  };

  const formatWeightTotal = (total: number) => {
    if (!total || total <= 0) return '—';
    let remaining = total;
    let vori = Math.floor(remaining);
    remaining = (remaining - vori) * 16;
    let ana = Math.floor(remaining);
    remaining = (remaining - ana) * 6;
    let roti = Math.floor(remaining);
    remaining = (remaining - roti) * 10;
    let point = Math.round(remaining);

    if (point >= 10) {
      point -= 10;
      roti += 1;
    }
    if (roti >= 6) {
      roti -= 6;
      ana += 1;
    }
    if (ana >= 16) {
      ana -= 16;
      vori += 1;
    }

    const parts = [];
    if (vori) parts.push(`${vori} Vori`);
    if (ana) parts.push(`${ana} Ana`);
    if (roti) parts.push(`${roti} Roti`);
    if (point) parts.push(`${point} Point`);

    return parts.length ? parts.join(', ') : '—';
  };

  const renderScreenRow = (t: Transaction) => (
    <tr 
        key={t.id} 
        style={{ backgroundColor: selectedIds.has(t.id) ? 'rgba(245, 158, 11, 0.1)' : 'transparent', transition: 'background-color 0.2s' }} 
        onMouseOver={(e) => { if (!selectedIds.has(t.id)) e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.03)';}} 
        onMouseOut={(e) => { if (!selectedIds.has(t.id)) e.currentTarget.style.backgroundColor = 'transparent';}}
    >
      <td style={{...tdStyles, padding: '0 15px'}} className="checkbox-col">
          <input
            type="checkbox"
            aria-label={`Select transaction for ${t.product}`}
            style={{ width: '1.2rem', height: '1.2rem', cursor: 'pointer', verticalAlign: 'middle' }}
            checked={selectedIds.has(t.id)}
            onChange={() => handleSelectOne(t.id)}
          />
      </td>
      <td style={tdStyles}>
        {t.product}
      </td>
      <td style={tdStyles}>{formatDate(t.purchaseDate)}</td>
      <td style={tdStyles}>{formatDate(t.saleDate)}</td>
      <td style={tdStyles}>{t.tokenNumber || '—'}</td>
      <td style={{...tdStyles, textAlign: 'left'}}>{formatWeight(t.weight)}</td>
      <td style={{...tdStyles, textAlign: 'right'}}>{formatCurrency(t.purchasePrice)}</td>
      <td style={{...tdStyles, textAlign: 'right'}}>{formatCurrency(t.salePrice)}</td>
      <td style={{...tdStyles, textAlign: 'right', color: t.profit === null ? 'inherit' : (t.profit >= 0 ? 'var(--success-color)' : 'var(--danger-color)'), fontWeight: t.profit !== null ? 600 : 400}}>{formatCurrency(t.profit)}</td>
      <td style={{...tdStyles, maxWidth: '200px', whiteSpace: 'pre-wrap', wordBreak: 'break-word'}}>{t.comment || '—'}</td>
      <td style={{...tdStyles, textAlign: 'center', fontWeight: 600}}>{determineStatus(t)}</td>
      <td style={tdStyles} className="no-print">
        <button style={{...buttonStyles, color: '#60a5fa', backgroundColor: 'rgba(59, 130, 246, 0.1)'}} onClick={() => onEdit(t)}>Edit</button>
        <button style={{...buttonStyles, color: '#4ade80', backgroundColor: 'rgba(34, 197, 94, 0.1)'}} onClick={() => onDuplicate(t)}>Copy</button>
        <button style={{...buttonStyles, color: 'var(--danger-color)', backgroundColor: 'rgba(239, 68, 68, 0.1)'}} onClick={() => onDelete(t.id)}>Delete</button>
      </td>
    </tr>
  );

  const renderPrintRow = (t: Transaction, idx: number) => (
    <tr key={`${t.id}-print-${idx}`}>
      <td>{t.product}</td>
      <td>{formatDate(t.purchaseDate)}</td>
      <td>{formatDate(t.saleDate)}</td>
      <td>{t.tokenNumber || '—'}</td>
      <td>{formatWeight(t.weight)}</td>
      <td style={{ textAlign: 'right' }}>{formatCurrency(t.purchasePrice)}</td>
      <td style={{ textAlign: 'right' }}>{formatCurrency(t.salePrice)}</td>
      <td style={{ textAlign: 'right' }}>{formatCurrency(t.profit)}</td>
      <td>{t.comment || '—'}</td>
      <td style={{ textAlign: 'center', fontWeight: 600 }}>{determineStatus(t)}</td>
    </tr>
  );

  if (transactions.length === 0) {
    return (
      <div style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-secondary-color)' }}>
        <p style={{ margin: 0, fontSize: '1.1rem' }}>No transactions found for this sheet.</p>
        <p style={{ fontSize: '0.9rem', marginTop: '0.75rem', lineHeight: 1.5 }}>
            Each sheet is separate. Use the tabs to switch sheets or click "+ Add Sheet" to create a new one for a different category.
        </p>
      </div>
    );
  }

  return (
    <div>
      <div style={{ overflowX: 'auto' }}>
        <table style={tableStyles} className="transaction-table screen-table">
          <thead>
            <tr>
              <th style={{...thStyles, width: '60px', padding: '0 15px'}} className="checkbox-col">
                  <input
                    type="checkbox"
                    aria-label="Select all transactions"
                    style={{ width: '1.2rem', height: '1.2rem', cursor: 'pointer', verticalAlign: 'middle' }}
                    checked={sortedDisplayTransactions.length > 0 && selectedIds.size === sortedDisplayTransactions.length}
                    onChange={handleSelectAll}
                    disabled={sortedDisplayTransactions.length === 0}
                  />
              </th>
              <th style={thStyles}>Product Name</th>
              <th style={thStyles}>Purchase Date</th>
              <th style={thStyles}>Sale Date</th>
              <th style={thStyles}>Token No.</th>
              <th style={{...thStyles, textAlign: 'left'}}>Weight</th>
              <th style={{...thStyles, textAlign: 'right'}}>Purchase Price</th>
              <th style={{...thStyles, textAlign: 'right'}}>Sale Price</th>
              <th style={{...thStyles, textAlign: 'right'}}>Profit</th>
              <th style={thStyles}>Comment</th>
              <th style={{...thStyles, textAlign: 'center'}}>Status</th>
              <th style={{...thStyles, width: '170px'}} className="no-print">Actions</th>
            </tr>
          </thead>
          <tbody className="screen-only">
            {currentTransactions.map(renderScreenRow)}
          </tbody>
          <tbody className="print-only">
            {sortedPrintTransactions.map(renderPrintRow)}
          </tbody>
          <tbody className="print-only-selected">
            {selectedPrintTransactions.map(renderPrintRow)}
          </tbody>
        </table>
      </div>

      {/* Print Summary - appears at the end after all products */}
      <div className="print-only print-summary-container">
        <table style={{...tableStyles, marginTop: '1rem', width: '100%', borderCollapse: 'collapse'}}>
          <tbody>
            <tr className="print-summary-row print-summary-full">
              <td colSpan={3} style={{padding: '2px 4px', borderBottom: '1px solid #333', fontWeight: 'bold'}}><strong>Total product in stock</strong></td>
              <td colSpan={2} style={{padding: '2px 4px', borderBottom: '1px solid #333'}}>{fullPrintSummary.inStockCount} pcs</td>
              <td colSpan={2} style={{padding: '2px 4px', borderBottom: '1px solid #333', fontWeight: 'bold'}}><strong>Total product sold</strong></td>
              <td colSpan={3} style={{padding: '2px 4px', borderBottom: '1px solid #333'}}>{fullPrintSummary.soldCount} pcs</td>
            </tr>
            <tr className="print-summary-row print-summary-full">
              <td colSpan={3} style={{padding: '2px 4px', borderBottom: '1px solid #333', fontWeight: 'bold'}}><strong>Purchase value (in stock)</strong></td>
              <td colSpan={2} style={{padding: '2px 4px', borderBottom: '1px solid #333', textAlign: 'right'}}>{formatCurrency(fullPrintSummary.inStockPurchaseValue)}</td>
              <td colSpan={2} style={{padding: '2px 4px', borderBottom: '1px solid #333', fontWeight: 'bold'}}><strong>Sales value (sold)</strong></td>
              <td colSpan={3} style={{padding: '2px 4px', borderBottom: '1px solid #333', textAlign: 'right'}}>{formatCurrency(fullPrintSummary.soldSalesValue)}</td>
            </tr>
            <tr className="print-summary-row print-summary-full">
              <td colSpan={3} style={{padding: '2px 4px', borderBottom: '1px solid #333', fontWeight: 'bold'}}><strong>Total weight in stock</strong></td>
              <td colSpan={2} style={{padding: '2px 4px', borderBottom: '1px solid #333'}}>{formatWeightTotal(fullPrintSummary.inStockWeight)}</td>
              <td colSpan={2} style={{padding: '2px 4px', borderBottom: '1px solid #333', fontWeight: 'bold'}}><strong>Total weight sold</strong></td>
              <td colSpan={3} style={{padding: '2px 4px', borderBottom: '1px solid #333'}}>{formatWeightTotal(fullPrintSummary.soldWeight)}</td>
            </tr>
            <tr className="print-summary-row print-summary-full" style={{display: 'table-row'}}>
              <td colSpan={5} style={{padding: '2px 4px', borderBottom: '1px solid #333', fontWeight: 'bold'}}><strong>Profit (sold)</strong></td>
              <td colSpan={5} style={{padding: '2px 4px', borderBottom: '1px solid #333', textAlign: 'right', fontWeight: 'bold'}}>{formatCurrency(fullPrintSummary.soldProfitValue)}</td>
            </tr>
            <tr className="print-summary-row print-summary-selected">
              <td colSpan={3} style={{padding: '2px 4px', borderBottom: '1px solid #333', fontWeight: 'bold'}}><strong>Total product in stock</strong></td>
              <td colSpan={2} style={{padding: '2px 4px', borderBottom: '1px solid #333'}}>{selectedPrintSummary.inStockCount} pcs</td>
              <td colSpan={2} style={{padding: '2px 4px', borderBottom: '1px solid #333', fontWeight: 'bold'}}><strong>Total product sold</strong></td>
              <td colSpan={3} style={{padding: '2px 4px', borderBottom: '1px solid #333'}}>{selectedPrintSummary.soldCount} pcs</td>
            </tr>
            <tr className="print-summary-row print-summary-selected">
              <td colSpan={3} style={{padding: '2px 4px', borderBottom: '1px solid #333', fontWeight: 'bold'}}><strong>Purchase value (in stock)</strong></td>
              <td colSpan={2} style={{padding: '2px 4px', borderBottom: '1px solid #333', textAlign: 'right'}}>{formatCurrency(selectedPrintSummary.inStockPurchaseValue)}</td>
              <td colSpan={2} style={{padding: '2px 4px', borderBottom: '1px solid #333', fontWeight: 'bold'}}><strong>Sales value (sold)</strong></td>
              <td colSpan={3} style={{padding: '2px 4px', borderBottom: '1px solid #333', textAlign: 'right'}}>{formatCurrency(selectedPrintSummary.soldSalesValue)}</td>
            </tr>
            <tr className="print-summary-row print-summary-selected">
              <td colSpan={3} style={{padding: '2px 4px', borderBottom: '1px solid #333', fontWeight: 'bold'}}><strong>Total weight in stock</strong></td>
              <td colSpan={2} style={{padding: '2px 4px', borderBottom: '1px solid #333'}}>{formatWeightTotal(selectedPrintSummary.inStockWeight)}</td>
              <td colSpan={2} style={{padding: '2px 4px', borderBottom: '1px solid #333', fontWeight: 'bold'}}><strong>Total weight sold</strong></td>
              <td colSpan={3} style={{padding: '2px 4px', borderBottom: '1px solid #333'}}>{formatWeightTotal(selectedPrintSummary.soldWeight)}</td>
            </tr>
            <tr className="print-summary-row print-summary-selected" style={{display: 'table-row'}}>
              <td colSpan={5} style={{padding: '2px 4px', borderBottom: '1px solid #333', fontWeight: 'bold'}}><strong>Profit (sold)</strong></td>
              <td colSpan={5} style={{padding: '2px 4px', borderBottom: '1px solid #333', textAlign: 'right', fontWeight: 'bold'}}>{formatCurrency(selectedPrintSummary.soldProfitValue)}</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="no-print" style={{ marginTop: '1rem', padding: '0.75rem 1rem', borderRadius: '8px', backgroundColor: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)', display: 'flex', flexWrap: 'wrap', gap: '1rem', fontSize: '0.95rem' }}>
        <span><strong>Total product in stock:</strong> {screenSummary.inStockCount} pcs</span>
        <span><strong>Total product sold:</strong> {screenSummary.soldCount} pcs</span>
        <span><strong>Purchase value (in stock):</strong> {formatCurrency(screenSummary.inStockPurchaseValue)}</span>
        <span><strong>Sales value (sold):</strong> {formatCurrency(screenSummary.soldSalesValue)}</span>
        <span><strong>Profit (sold):</strong> <span style={{ color: screenSummary.soldProfitValue >= 0 ? 'var(--success-color)' : 'var(--danger-color)' }}>{formatCurrency(screenSummary.soldProfitValue)}</span></span>
        <span><strong>Total weight in stock:</strong> {formatWeightTotal(screenSummary.inStockWeight)}</span>
        <span><strong>Total weight sold:</strong> {formatWeightTotal(screenSummary.soldWeight)}</span>
      </div>

      <div className="no-print" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '1rem', padding: '0.5rem', color: 'var(--text-secondary-color)' }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
            <button
              onClick={handlePrintAll}
              style={{ padding: '0.5rem 1rem', border: '1px solid var(--border-color)', borderRadius: '6px', cursor: 'pointer', backgroundColor: 'var(--card-background)', color: 'var(--text-color)' }}
            >
              Print Full List
            </button>
            {selectedIds.size > 0 && (
              <>
                <button
                  onClick={handlePrintSelected}
                  style={{ marginLeft: '0.5rem', padding: '0.5rem 1rem', border: '1px solid var(--primary-color)', borderRadius: '6px', cursor: 'pointer', backgroundColor: 'rgba(245, 158, 11, 0.1)', color: 'var(--primary-color)', fontWeight: 500 }}
                >
                  Print Selected ({selectedIds.size})
                </button>
                <button
                  onClick={handleBulkDeleteClick}
                  style={{ marginLeft: '0.5rem', padding: '0.5rem 1rem', border: '1px solid var(--danger-color)', borderRadius: '6px', cursor: 'pointer', backgroundColor: 'rgba(239, 68, 68, 0.12)', color: 'var(--danger-color)', fontWeight: 500 }}
                >
                  Delete Selected ({selectedIds.size})
                </button>
              </>
            )}
            <button
              onClick={() => handleSavePdf(false)}
              style={{ padding: '0.5rem 1rem', border: '1px solid var(--accent-blue)', borderRadius: '6px', cursor: 'pointer', backgroundColor: 'rgba(37, 99, 235, 0.12)', color: 'var(--accent-blue)', fontWeight: 500 }}
            >
              Save as PDF
            </button>
            {selectedIds.size > 0 && (
              <button
                onClick={() => handleSavePdf(true)}
                style={{ padding: '0.5rem 1rem', border: '1px solid var(--accent-purple)', borderRadius: '6px', cursor: 'pointer', backgroundColor: 'rgba(99, 102, 241, 0.15)', color: 'var(--accent-purple)', fontWeight: 500 }}
              >
                Save Selected as PDF ({selectedIds.size})
              </button>
            )}
        </div>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <button
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            style={{ padding: '0.5rem 1rem', border: '1px solid var(--border-color)', borderRadius: '6px', cursor: 'pointer', backgroundColor: 'var(--card-background)', marginRight: '0.5rem', opacity: currentPage === 1 ? 0.5 : 1, color: 'var(--text-color)' }}
          >
            Previous
          </button>
          <span>Page {currentPage} of {totalPages}</span>
          <button
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            style={{ padding: '0.5rem 1rem', border: '1px solid var(--border-color)', borderRadius: '6px', cursor: 'pointer', backgroundColor: 'var(--card-background)', marginLeft: '0.5rem', opacity: currentPage === totalPages ? 0.5 : 1, color: 'var(--text-color)' }}
          >
            Next
          </button>
        </div>
        <div style={{fontSize: '0.9rem'}}>
          Showing {transactions.length > 0 ? startIndex + 1 : 0} - {Math.min(endIndex, transactions.length)} of {transactions.length} entries
        </div>
      </div>
    </div>
  );
};

export default TransactionTable;
