import React, { useState, useMemo, useEffect, FC } from 'react';
import Modal from './Modal';
import { useLocalStorage } from '../hooks/useLocalStorage';

// Helper function to convert numbers to Bengali words
function numberToBengaliWords(num: number): string {
  if (isNaN(num)) return '';
  const bnNumbers = [
    '', 'এক', 'দুই', 'তিন', 'চার', 'পাঁচ', 'ছয়', 'সাত', 'আট', 'নয়', 'দশ',
    'এগারো', 'বারো', 'তেরো', 'চৌদ্দ', 'পনেরো', 'ষোল', 'সতেরো', 'আঠারো', 'ঊনিশ',
    'বিশ', 'একুশ', 'বাইশ', 'তেইশ', 'চব্বিশ', 'পঁচিশ', 'ছাব্বিশ', 'সাতাশ', 'আটাশ', 'ঊনত্রিশ',
    'ত্রিশ', 'একত্রিশ', 'বত্রিশ', 'তেত্রিশ', 'চৌত্রিশ', 'পঁয়ত্রিশ', 'ছত্রিশ', 'সাঁইত্রিশ', 'আটত্রিশ', 'ঊনচল্লিশ',
    'চল্লিশ', 'একচল্লিশ', 'বিয়াল্লিশ', 'তেতাল্লিশ', 'চুয়াল্লিশ', 'পঁয়তাল্লিশ', 'ছেচল্লিশ', 'সাতচল্লিশ', 'আটচল্লিশ', 'ঊনপঞ্চাশ',
    'পঞ্চাশ', 'একান্ন', 'বাহান্ন', 'তিপ্পান্ন', 'চুয়ান্ন', 'পঞ্চান্ন', 'ছাপ্পان্ন', 'সাতান্ন', 'আটান্ন', 'ঊনষাট',
    'ষাট', 'একষট্টি', 'বাষট্টি', 'তেষট্টি', 'চৌষট্টি', 'পঁয়ষট্টি', 'ছেষট্টি', 'সাতষট্টি', 'আটষট্টি', 'ঊনসত্তর',
    'সত্তর', 'একাত্তর', 'বাহাত্তর', 'তিয়াত্তর', 'চুয়াত্তর', 'পঁচাত্তর', 'ছিয়াত্তর', 'সাতাত্তর', 'আটাত্তর', 'ঊনআশি',
    'আশি', 'একাশি', 'বিরাশি', 'তিরাশি', 'চুরাশি', 'পঁচাশি', 'ছিয়াশি', 'সাতাশি', 'আটাশি', 'ঊননব্বই',
    'নব্বই', 'একানব্বই', 'বিরানব্বই', 'তিরানব্বই', 'চুরানব্বই', 'পঁচানব্বই', 'ছিয়ানব্বই', 'সাতানব্বই', 'আটানব্বই', 'নিরানব্বই'
  ];
  function getWord(n: number) {
    if (n === 0) return '';
    if (n < 100) return bnNumbers[n];
    if (n < 1000) {
      const hundred = Math.floor(n / 100);
      const rest = n % 100;
      return bnNumbers[hundred] + ' শত' + (rest ? ' ' + getWord(rest) : '');
    }
    return '';
  }
  function convert(n: number) {
    if (n === 0) return 'শূন্য';
    let result = '';
    const crore = Math.floor(n / 10000000);
    n %= 10000000;
    const lakh = Math.floor(n / 100000);
    n %= 100000;
    const thousand = Math.floor(n / 1000);
    n %= 1000;
    const hundred = Math.floor(n / 100);
    const rest = n % 100;
    if (crore) result += getWord(crore) + ' কোটি ';
    if (lakh) result += getWord(lakh) + ' লাখ ';
    if (thousand) result += getWord(thousand) + ' হাজার ';
    if (hundred) result += bnNumbers[hundred] + ' শত ';
    if (rest) result += getWord(rest) + ' ';
    return result.trim();
  }
  return convert(Math.floor(num)) + ' টাকা';
}

interface GoldCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPriceCalculated?: (price: number) => void;
  initialWeight?: { vori: number; ana: number; roti: number; point: number };
}
type WageUnit = 'vori' | 'ana';

interface CalcState {
  vori: string; ana: string; roti: string; point: string;
  rate: string; wage: string; wageUnit: WageUnit;
  grams: string;
  vatPercent: string;
  taxPercent: string;
}

interface HistoryItem {
    id: string;
    totalPrice: number;
    totalVori: number;
    vori: string; ana: string; roti: string; point: string;
    rate: string; wage: string; wageUnit: WageUnit;
    vatPercent: string;
    taxPercent: string;
}

const GoldCalculatorModal: FC<GoldCalculatorModalProps> = ({ isOpen, onClose, onPriceCalculated, initialWeight }) => {
  const [inputs, setInputs] = useState<CalcState>({
    vori: initialWeight?.vori ? String(initialWeight.vori) : '',
    ana: initialWeight?.ana ? String(initialWeight.ana) : '',
    roti: initialWeight?.roti ? String(initialWeight.roti) : '',
    point: initialWeight?.point ? String(initialWeight.point) : '',
    rate: '110000', wage: '5000', wageUnit: 'vori',
    grams: '',
    vatPercent: '0',
    taxPercent: '0'
  });
  const [history, setHistory] = useLocalStorage<HistoryItem[]>('goldCalcHistory', []);

  useEffect(() => {
    if (initialWeight && isOpen) {
      setInputs(prev => ({
        ...prev,
        vori: initialWeight.vori ? String(initialWeight.vori) : prev.vori,
        ana: initialWeight.ana ? String(initialWeight.ana) : prev.ana,
        roti: initialWeight.roti ? String(initialWeight.roti) : prev.roti,
        point: initialWeight.point ? String(initialWeight.point) : prev.point,
      }));
    }
  }, [initialWeight, isOpen]);

  const calculation = useMemo(() => {
    const voriNum = parseFloat(inputs.vori) || 0;
    const anaNum = parseFloat(inputs.ana) || 0;
    const rotiNum = parseFloat(inputs.roti) || 0;
    const pointNum = parseFloat(inputs.point) || 0;
    const rateNum = parseFloat(inputs.rate) || 0;
    const wageNum = parseFloat(inputs.wage) || 0;
    const vatPercent = parseFloat(inputs.vatPercent) || 0;
    const taxPercent = parseFloat(inputs.taxPercent) || 0;

    const totalVori = voriNum + (anaNum / 16) + (rotiNum / 96) + (pointNum / 960);
    const goldCost = totalVori * rateNum;

    let makingCost = 0;
    if (inputs.wageUnit === 'vori') {
      makingCost = totalVori * wageNum;
    } else if (inputs.wageUnit === 'ana') {
      makingCost = (totalVori * 16) * wageNum;
    }
    
    const subtotal = goldCost + makingCost;
    const vatAmount = (subtotal * vatPercent) / 100;
    const taxAmount = (subtotal * taxPercent) / 100;
    const totalPrice = subtotal + vatAmount + taxAmount;

    return { totalVori, goldCost, makingCost, vatAmount, taxAmount, subtotal, totalPrice };
  }, [inputs.vori, inputs.ana, inputs.roti, inputs.point, inputs.rate, inputs.wage, inputs.wageUnit, inputs.vatPercent, inputs.taxPercent]);

  const VORI_TO_GRAM = 11.664;

  const updateGramsFromVoriState = (next: CalcState): CalcState => {
    const voriNum = parseFloat(next.vori) || 0;
    const anaNum = parseFloat(next.ana) || 0;
    const rotiNum = parseFloat(next.roti) || 0;
    const pointNum = parseFloat(next.point) || 0;
    const totalVori = voriNum + anaNum / 16 + rotiNum / 96 + pointNum / 960;
    const grams = totalVori > 0 ? (totalVori * VORI_TO_GRAM).toFixed(3) : '';
    return { ...next, grams };
  };

  const normalizeVoriFromGrams = (gramsValue: number) => {
    const totalVori = gramsValue / VORI_TO_GRAM;
    let remaining = totalVori;
    let vori = Math.floor(remaining);
    remaining = (remaining - vori) * 16;
    let ana = Math.floor(remaining);
    remaining = (remaining - ana) * 6;
    let roti = Math.floor(remaining);
    remaining = (remaining - roti) * 10;
    let point = Math.round(remaining);

    if (point >= 10) {
      point -= 10;
      roti += 1;
    }
    if (roti >= 6) {
      roti -= 6;
      ana += 1;
    }
    if (ana >= 16) {
      ana -= 16;
      vori += 1;
    }

    return {
      vori: vori ? String(vori) : '',
      ana: ana ? String(ana) : '',
      roti: roti ? String(roti) : '',
      point: point ? String(point) : '',
    };
  };

  const handleWeightInputChange = (field: 'vori' | 'ana' | 'roti' | 'point', value: string) => {
    setInputs(prev => {
      const next: CalcState = { ...prev, [field]: value };
      return updateGramsFromVoriState(next);
    });
  };

  const handleGramsChange = (value: string) => {
    setInputs(prev => {
      const gramsNum = parseFloat(value);
      if (Number.isNaN(gramsNum) || gramsNum <= 0) {
        return { ...prev, grams: value, vori: '', ana: '', roti: '', point: '' };
      }
      const parts = normalizeVoriFromGrams(gramsNum);
      return {
        ...prev,
        grams: value,
        ...parts,
      };
    });
  };

  const handleInputChange = (field: 'rate' | 'wage' | 'wageUnit' | 'vatPercent' | 'taxPercent', value: string) => {
    setInputs(prev => ({ ...prev, [field]: value }));
  };

  const handleFillPrice = () => {
    if (onPriceCalculated && calculation.totalPrice > 0) {
      onPriceCalculated(calculation.totalPrice);
      onClose();
    }
  };

  const handleCalculateAndSave = () => {
    if (calculation.totalVori <= 0) return;
    const newHistoryItem: HistoryItem = {
      vori: inputs.vori,
      ana: inputs.ana,
      roti: inputs.roti,
      point: inputs.point,
      rate: inputs.rate,
      wage: inputs.wage,
      wageUnit: inputs.wageUnit,
      vatPercent: inputs.vatPercent,
      taxPercent: inputs.taxPercent,
      id: new Date().toISOString(),
      totalPrice: calculation.totalPrice,
      totalVori: calculation.totalVori,
    };
    setHistory([newHistoryItem, ...history.slice(0, 9)]); // Keep last 10
  };
  
  const restoreFromHistory = (item: HistoryItem) => {
    setInputs({
        vori: item.vori,
        ana: item.ana,
        roti: item.roti,
        point: item.point,
        rate: item.rate,
        wage: item.wage,
        wageUnit: item.wageUnit,
        vatPercent: item.vatPercent || '0',
        taxPercent: item.taxPercent || '0',
        grams: ''
    });
  };

  // STYLES
  const labelStyle: React.CSSProperties = { display: 'block', marginBottom: '0.5rem', fontWeight: 500, color: 'var(--text-secondary-color)', fontSize: '0.9rem' };
  const inputStyle: React.CSSProperties = { width: '100%', padding: '0.6rem', border: '1px solid var(--border-color)', borderRadius: '6px', backgroundColor: 'var(--background-color)', color: 'var(--text-color)' };
  const resultCardStyle: React.CSSProperties = { background: 'var(--background-color)', border: '1px solid var(--border-color)', borderRadius: '8px', padding: '1rem', height: '100%' };
  const resultRowStyle: React.CSSProperties = { display: 'flex', justifyContent: 'space-between', padding: '0.75rem 0', borderBottom: '1px solid var(--border-color)' };
  const historyTableStyle: React.CSSProperties = { width: '100%', borderCollapse: 'collapse', marginTop: '1rem', fontSize: '0.85rem' };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="ওজন ও মূল্য ক্যালকুলেটর">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '2rem' }}>
        {/* Input Column */}
        <div>
          <h3 style={{ marginTop: 0, borderBottom: '1px solid var(--border-color)', paddingBottom: '0.5rem', color: 'var(--text-color)' }}>ওজন ও দামের ইনপুট</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
            <div>
              <label style={labelStyle}>ভরি</label>
              <input type="number" style={inputStyle} value={inputs.vori} onChange={(e) => handleWeightInputChange('vori', e.target.value)} />
            </div>
            <div>
              <label style={labelStyle}>আনা</label>
              <input type="number" style={inputStyle} value={inputs.ana} onChange={(e) => handleWeightInputChange('ana', e.target.value)} />
            </div>
            <div>
              <label style={labelStyle}>রতি</label>
              <input type="number" style={inputStyle} value={inputs.roti} onChange={(e) => handleWeightInputChange('roti', e.target.value)} />
            </div>
            <div>
              <label style={labelStyle}>পয়েন্ট</label>
              <input type="number" style={inputStyle} value={inputs.point} onChange={(e) => handleWeightInputChange('point', e.target.value)} />
            </div>
          </div>
          <div style={{ marginBottom: '1rem' }}>
            <label style={labelStyle}>ওজন (গ্রাম)</label>
            <input
              type="number"
              style={inputStyle}
              value={inputs.grams}
              onChange={(e) => handleGramsChange(e.target.value)}
              placeholder="যেমন 11.664"
            />
            <div style={{ marginTop: '0.35rem', fontSize: '0.8rem', color: 'var(--text-secondary-color)' }}>
              ১ ভরি ≈ {VORI_TO_GRAM} গ্রাম
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
             <div>
                <label style={labelStyle}>প্রতি ভরি সোনার দাম (৳)</label>
                <input type="number" style={inputStyle} value={inputs.rate} onChange={(e) => handleInputChange('rate', e.target.value)} />
             </div>
             <div>
                <label style={labelStyle}>মজুরি প্রতি ইউনিট (৳)</label>
                <input type="number" style={inputStyle} value={inputs.wage} onChange={(e) => handleInputChange('wage', e.target.value)} />
             </div>
             <div>
                <label style={labelStyle}>মজুরি হিসাবের ইউনিট</label>
                <select style={inputStyle} value={inputs.wageUnit} onChange={(e) => handleInputChange('wageUnit', e.target.value as WageUnit)}>
                    <option value="vori">প্রতি ভরি</option>
                    <option value="ana">প্রতি আনা</option>
                </select>
             </div>
             <div>
                <label style={labelStyle}>VAT (%)</label>
                <input type="number" step="0.01" style={inputStyle} value={inputs.vatPercent} onChange={(e) => handleInputChange('vatPercent', e.target.value)} placeholder="0" />
             </div>
             <div>
                <label style={labelStyle}>Tax (%)</label>
                <input type="number" step="0.01" style={inputStyle} value={inputs.taxPercent} onChange={(e) => handleInputChange('taxPercent', e.target.value)} placeholder="0" />
             </div>
          </div>
           <button 
                onClick={handleCalculateAndSave} 
                style={{width: '100%', padding: '0.8rem', border: 'none', borderRadius: '6px', cursor: 'pointer', backgroundColor: 'var(--primary-color)', color: '#111827', fontWeight: 'bold', marginTop: '1.5rem', fontSize: '1rem'}}
            >
                Calculate & Save
            </button>
        </div>

        {/* Result Column */}
        <div>
           <h3 style={{ marginTop: 0, borderBottom: '1px solid var(--border-color)', paddingBottom: '0.5rem', color: 'var(--text-color)' }}>হিসাবের ফলাফল</h3>
           <div style={resultCardStyle}>
                <div style={resultRowStyle}><span style={labelStyle}>Total Weight</span> <strong>{calculation.totalVori.toFixed(4)} Vori</strong></div>
                <div style={resultRowStyle}><span style={labelStyle}>Gold Price</span> <span>৳ {calculation.goldCost.toFixed(2)}</span></div>
                <div style={resultRowStyle}><span style={labelStyle}>Making Wage</span> <span>৳ {calculation.makingCost.toFixed(2)}</span></div>
                <div style={resultRowStyle}><span style={labelStyle}>Subtotal</span> <span>৳ {calculation.subtotal.toFixed(2)}</span></div>
                {calculation.vatAmount > 0 && (
                  <div style={resultRowStyle}><span style={labelStyle}>VAT ({inputs.vatPercent}%)</span> <span>৳ {calculation.vatAmount.toFixed(2)}</span></div>
                )}
                {calculation.taxAmount > 0 && (
                  <div style={resultRowStyle}><span style={labelStyle}>Tax ({inputs.taxPercent}%)</span> <span>৳ {calculation.taxAmount.toFixed(2)}</span></div>
                )}
                <div style={{...resultRowStyle, borderBottom: 'none', background: 'var(--card-background)', padding: '1rem', marginTop: '1rem', borderRadius: '6px' }}>
                    <span style={{color: 'var(--primary-color)', fontWeight: 'bold'}}>Total Price</span>
                    <strong style={{color: 'var(--primary-color)', fontSize: '1.2rem'}}>৳ {calculation.totalPrice.toFixed(2)}</strong>
                </div>
                 <div style={{textAlign: 'center', marginTop: '1rem', color: 'var(--text-secondary-color)', fontStyle: 'italic'}}>
                    {numberToBengaliWords(calculation.totalPrice)}
                </div>
                {onPriceCalculated && (
                  <button 
                    onClick={handleFillPrice}
                    disabled={calculation.totalPrice <= 0}
                    style={{
                      width: '100%',
                      padding: '0.8rem',
                      border: 'none',
                      borderRadius: '6px',
                      cursor: calculation.totalPrice > 0 ? 'pointer' : 'not-allowed',
                      backgroundColor: calculation.totalPrice > 0 ? 'var(--primary-color)' : 'var(--border-color)',
                      color: '#111827',
                      fontWeight: 'bold',
                      marginTop: '1.5rem',
                      fontSize: '1rem',
                      opacity: calculation.totalPrice > 0 ? 1 : 0.6
                    }}
                  >
                    Fill Price in Form
                  </button>
                )}
           </div>
        </div>
      </div>

      {/* History Section */}
      <div style={{ marginTop: '2rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.5rem' }}>
            <h3 style={{ margin: 0 }}>Calculation History</h3>
            {history.length > 0 && <button onClick={() => setHistory([])} style={{background: 'none', border: 'none', color: 'var(--danger-color)', cursor: 'pointer', fontSize: '0.85rem'}}>Clear History</button>}
        </div>
        {history.length > 0 ? (
            <div style={{ maxHeight: '200px', overflowY: 'auto', marginTop: '1rem' }}>
                <table style={historyTableStyle}>
                    <thead style={{textAlign: 'left'}}>
                        <tr>
                            <th style={{padding: '8px'}}>Weight</th>
                            <th style={{padding: '8px'}}>Total Price</th>
                            <th style={{padding: '8px'}}>Date</th>
                            <th style={{padding: '8px'}}>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {history.map(item => (
                            <tr key={item.id} style={{ borderBottom: '1px solid var(--border-color)'}}>
                                <td style={{padding: '8px'}}>{item.totalVori.toFixed(4)} Vori</td>
                                <td style={{padding: '8px'}}>৳ {item.totalPrice.toFixed(2)}</td>
                                <td style={{padding: '8px'}}>{new Date(item.id).toLocaleTimeString()}</td>
                                <td style={{padding: '8px'}}>
                                    <button onClick={() => restoreFromHistory(item)} style={{background: 'none', border: '1px solid var(--border-color)', color: 'var(--primary-color)', cursor: 'pointer', borderRadius: '4px', padding: '4px 8px'}}>Load</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        ) : (
            <p style={{textAlign: 'center', color: 'var(--text-secondary-color)', marginTop: '1.5rem'}}>No history yet. Perform a calculation to save it here.</p>
        )}
      </div>
    </Modal>
  );
};

export default GoldCalculatorModal;