import React, { useState } from 'react';
import Modal from './Modal';

interface PasswordPromptModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (username: string, password: string) => void;
  title: string;
}

const PasswordPromptModal: React.FC<PasswordPromptModalProps> = ({ isOpen, onClose, onConfirm, title }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleConfirm = () => {
    onConfirm(username, password);
    setUsername('');
    setPassword('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleConfirm();
  };
  
  const labelStyle: React.CSSProperties = { display: 'block', marginBottom: '0.5rem', fontWeight: 500, color: 'var(--text-secondary-color)' };
  const inputStyle: React.CSSProperties = { width: '100%', padding: '0.7rem', border: '1px solid var(--border-color)', borderRadius: '6px', backgroundColor: 'var(--background-color)', color: 'var(--text-color)', fontSize: '1rem' };
  const buttonContainer: React.CSSProperties = { display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '1.5rem' };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={title}>
      <form onSubmit={handleSubmit}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
           <div>
              <label style={labelStyle} htmlFor="admin-username">Admin Username</label>
              <input
                style={inputStyle}
                type="text"
                id="admin-username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                autoFocus
              />
            </div>
            <div>
              <label style={labelStyle} htmlFor="admin-password">Admin Password</label>
              <input
                style={inputStyle}
                type="password"
                id="admin-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
        </div>
        <div style={buttonContainer}>
           <button type="button" onClick={onClose} style={{padding: '0.6rem 1.2rem', border: '1px solid var(--border-color)', borderRadius: '6px', cursor: 'pointer', backgroundColor: 'transparent', color: 'var(--text-color)'}}>Cancel</button>
           <button type="submit" style={{padding: '0.6rem 1.2rem', border: 'none', borderRadius: '6px', cursor: 'pointer', backgroundColor: 'var(--danger-color)', color: '#fff', fontWeight: 'bold'}}>Confirm Action</button>
        </div>
      </form>
    </Modal>
  );
};

export default PasswordPromptModal;