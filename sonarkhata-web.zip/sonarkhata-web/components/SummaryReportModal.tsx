import React, { useMemo, useState } from 'react';
import Modal from './Modal';
import { Transaction } from '../types';

interface SummaryReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: Transaction[];
  sheetName: string;
  appTitle: string;
  onNotify?: (message: string, type: 'success' | 'error') => void;
}

type Period = '1m' | '6m' | '12m' | 'all';

const periodLabelMap: Record<Period, string> = {
  '1m': 'Last 1 Month',
  '6m': 'Last 6 Months',
  '12m': 'Last 12 Months',
  'all': 'All Time'
};

const SummaryReportModal: React.FC<SummaryReportModalProps> = ({ isOpen, onClose, transactions, sheetName, appTitle, onNotify }) => {
  const [period, setPeriod] = useState<Period | 'custom'>('all');
  const [customStartDate, setCustomStartDate] = useState<string>("");
  const [customEndDate, setCustomEndDate] = useState<string>("");
  const electronAPI = typeof window !== 'undefined' ? (window as any).electronAPI : undefined;

  const reportData = useMemo(() => {
    try {
      if (!Array.isArray(transactions)) {
        return {
          totalPurchase: 0,
          totalSales: 0,
          totalProfit: 0,
          soldCount: 0,
          inStockCount: 0,
          totalWeightSoldInVori: 0,
          totalWeightInStockInVori: 0,
          totalPurchaseInStock: 0,
          period
        };
      }
      const now = new Date();
      let startDate = new Date(0);
      let endDate = new Date();
      if (period === '1m') {
        startDate = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());
      } else if (period === '6m') {
        startDate = new Date(now.getFullYear(), now.getMonth() - 6, now.getDate());
      } else if (period === '12m') {
        startDate = new Date(now.getFullYear() - 1, now.getMonth(), now.getDate());
      } else if (period === 'custom' && customStartDate) {
        startDate = new Date(customStartDate);
      }
      if (period === 'custom' && customEndDate) {
        endDate = new Date(customEndDate);
        endDate.setHours(23,59,59,999);
      } else {
        endDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23,59,59,999);
      }

      const soldTransactions = transactions.filter(t => {
        if (!t || !t.saleDate) return false;
        const saleD = new Date(t.saleDate);
        if (isNaN(saleD.getTime())) return false;
        return saleD >= startDate && saleD <= endDate;
      });
      const inStockTransactions = transactions.filter(t => {
        if (!t || !t.purchaseDate) return false;
        const pDate = new Date(t.purchaseDate);
        if (isNaN(pDate.getTime())) return false;
        const sDate = t.saleDate ? new Date(t.saleDate) : null;
        return pDate >= startDate && pDate <= endDate && (!sDate || isNaN(sDate.getTime()) || sDate > endDate);
      });
      const filteredTransactions = transactions.filter(t => {
        if (!t || !t.purchaseDate) return false;
        const pDate = new Date(t.purchaseDate);
        if (isNaN(pDate.getTime())) return false;
        return pDate >= startDate && pDate <= endDate;
      });

      const safeReduce = (arr, cb, init) => Array.isArray(arr) ? arr.reduce(cb, init) : init;

      const totalPurchase = safeReduce(filteredTransactions, (sum, t) => sum + (t && t.purchasePrice ? t.purchasePrice : 0), 0);
      const totalSales = safeReduce(soldTransactions, (sum, t) => sum + (t && t.salePrice ? t.salePrice : 0), 0);
      const totalProfit = safeReduce(soldTransactions, (sum, t) => sum + (t && t.profit ? t.profit : 0), 0);
      const soldCount = Array.isArray(soldTransactions) ? soldTransactions.length : 0;
      const inStockCount = Array.isArray(inStockTransactions) ? inStockTransactions.length : 0;

      const totalWeightSoldInVori = safeReduce(soldTransactions, (sum, t) => sum + (t && t.totalWeightInVori ? t.totalWeightInVori : 0), 0);
      const totalWeightInStockInVori = safeReduce(inStockTransactions, (sum, t) => sum + (t && t.totalWeightInVori ? t.totalWeightInVori : 0), 0);
      const totalPurchaseInStock = safeReduce(inStockTransactions, (sum, t) => sum + (t && t.purchasePrice ? t.purchasePrice : 0), 0);

      return { 
        totalPurchase, 
        totalSales, 
        totalProfit, 
        soldCount, 
        inStockCount, 
        totalWeightSoldInVori, 
        totalWeightInStockInVori,
        totalPurchaseInStock,
        period 
      };
    } catch (error) {
      console.error('Error calculating report data:', error);
      return {
        totalPurchase: 0,
        totalSales: 0,
        totalProfit: 0,
        soldCount: 0,
        inStockCount: 0,
        totalWeightSoldInVori: 0,
        totalWeightInStockInVori: 0,
        totalPurchaseInStock: 0,
        period
      };
    }
  }, [transactions, period, customStartDate, customEndDate]);

  const normalizeWeightUnits = (totalVori: number) => {
    let remaining = totalVori || 0;
    let vori = Math.floor(remaining);
    remaining = (remaining - vori) * 16;
    let ana = Math.floor(remaining);
    remaining = (remaining - ana) * 6;
    let roti = Math.floor(remaining);
    remaining = (remaining - roti) * 10;
    let point = Math.round(remaining);

    if (point >= 10) {
      point -= 10;
      roti += 1;
    }
    if (roti >= 6) {
      roti -= 6;
      ana += 1;
    }
    if (ana >= 16) {
      ana -= 16;
      vori += 1;
    }

    return { vori, ana, roti, point };
  };

  const formatWeightFromUnits = ({ vori, ana, roti, point }: ReturnType<typeof normalizeWeightUnits>) => {
    const parts = [];
    if (vori > 0) parts.push(`${vori} ভরি`);
    if (ana > 0) parts.push(`${ana} আনা`);
    if (roti > 0) parts.push(`${roti} রতি`);
    if (point > 0) parts.push(`${point} পয়েন্ট`);
    return parts.length > 0 ? parts.join(', ') : '০ ভরি';
  };

  const weightSoldUnits = normalizeWeightUnits(reportData.totalWeightSoldInVori);
  const weightStockUnits = normalizeWeightUnits(reportData.totalWeightInStockInVori);
  
  const formatCurrency = (amount: number) => {
    if (amount === null || amount === undefined || isNaN(amount)) {
      return '৳ 0.00';
    }
    return `৳ ${amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const periodButtonStyle: React.CSSProperties = {
    padding: '0.5rem 1rem',
    border: '1px solid var(--border-color)',
    borderRadius: '6px',
    cursor: 'pointer',
    backgroundColor: 'transparent',
    color: 'var(--text-secondary-color)',
    fontSize: '0.9rem'
  };

  const activePeriodButtonStyle: React.CSSProperties = {
    ...periodButtonStyle,
    backgroundColor: 'var(--primary-color)',
    color: '#fff',
    borderColor: 'var(--primary-color)',
  };

  const reportContainerStyle: React.CSSProperties = {
    backgroundColor: '#fff',
    color: '#111',
    padding: '2rem',
    borderRadius: '16px',
    border: '1px solid #e5e7eb',
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
    boxShadow: '0 20px 40px rgba(0,0,0,0.1)',
    background: 'linear-gradient(135deg, #ffffff 0%, #f9fafb 100%)'
  };

  const headerStyle: React.CSSProperties = {
    textAlign: 'center',
    marginBottom: '2rem',
    lineHeight: 1.4,
    letterSpacing: '0.05em',
    paddingBottom: '1.5rem',
    borderBottom: '3px solid #f59e0b',
    background: 'linear-gradient(135deg, #fef3c7 0%, #fde68a 100%)',
    borderRadius: '12px',
    padding: '1.5rem'
  };

  const metaGridStyle: React.CSSProperties = {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))',
    gap: '0.5rem',
    fontSize: '0.95rem',
    marginBottom: '1.5rem'
  };

  const summaryTableStyle: React.CSSProperties = {
    width: '100%',
    borderCollapse: 'collapse',
    fontSize: '0.95rem'
  };

  const summaryThStyle: React.CSSProperties = {
    border: '1px solid #9ca3af',
    padding: '0.75rem',
    backgroundColor: '#f3f4f6',
    fontWeight: 600,
    textAlign: 'left'
  };

  const summaryTdStyle: React.CSSProperties = {
    border: '1px solid #d1d5db',
    padding: '0.7rem',
    verticalAlign: 'top'
  };

  const profitMargin = reportData.totalSales > 0 ? ((reportData.totalProfit / reportData.totalSales) * 100) : 0;
  const totalItems = reportData.soldCount + reportData.inStockCount;
  const soldPercentage = totalItems > 0 ? ((reportData.soldCount / totalItems) * 100) : 0;

  const summaryRows = [
    { label: 'Products Sold', value: reportData.soldCount.toString(), icon: '✅', color: '#10b981', bg: '#d1fae5' },
    { label: 'Products in Stock', value: reportData.inStockCount.toString(), icon: '📦', color: '#3b82f6', bg: '#dbeafe' },
    { label: 'Total Weight Sold', value: formatWeightFromUnits(weightSoldUnits), icon: '⚖️', color: '#8b5cf6', bg: '#ede9fe' },
    { label: 'Total Weight in Stock', value: formatWeightFromUnits(weightStockUnits), icon: '📊', color: '#06b6d4', bg: '#cffafe' },
    { label: 'Total Purchase Value (Period)', value: formatCurrency(reportData.totalPurchase), icon: '💰', color: '#f59e0b', bg: '#fef3c7' },
    { label: 'Total Purchase Value (In Stock)', value: formatCurrency(reportData.totalPurchaseInStock), icon: '💵', color: '#ef4444', bg: '#fee2e2' },
    { label: 'Total Sales Value (Period)', value: formatCurrency(reportData.totalSales), icon: '💸', color: '#14b8a6', bg: '#ccfbf1' },
    { label: 'Total Profit (Period)', value: formatCurrency(reportData.totalProfit), highlight: true, icon: '🎯', color: reportData.totalProfit >= 0 ? '#10b981' : '#ef4444', bg: reportData.totalProfit >= 0 ? '#d1fae5' : '#fee2e2' },
  ];

  const printButtonStyle: React.CSSProperties = {
    padding: '0.55rem 1.15rem',
    borderRadius: '6px',
    border: 'none',
    background: 'linear-gradient(90deg, #fcd77f, #f5b948)',
    color: '#1a1200',
    fontWeight: 600,
    cursor: 'pointer',
    boxShadow: '0 5px 15px rgba(252, 215, 127, 0.35)'
  };

  const pdfButtonStyle: React.CSSProperties = {
    padding: '0.55rem 1.15rem',
    borderRadius: '6px',
    border: 'none',
    background: 'linear-gradient(90deg, #2563eb, #1d4ed8)',
    color: '#ffffff',
    fontWeight: 600,
    cursor: 'pointer',
    boxShadow: '0 5px 15px rgba(37, 99, 235, 0.35)'
  };

  const handlePrintReport = () => {
    const reportElement = document.querySelector('.printable-report-card');
    if (!reportElement) return;
    const printWindow = window.open('', '_blank', 'width=900,height=650');
    if (!printWindow) return;
    const styles = `
      body { margin: 0; padding: 20px; font-family: 'Times New Roman', serif; background: #fff; color: #111; }
      table { width: 100%; border-collapse: collapse; }
      th, td { border: 1px solid #9ca3af; padding: 10px; }
      th { background: #f3f4f6; }
      h2 { text-align: center; }
    `;
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8" />
          <title>Stock Verification Report</title>
          <style>${styles}</style>
        </head>
        <body>${reportElement.outerHTML}</body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
    printWindow.close();
  };

  const runWithSummaryPrintContext = async <T,>(action: () => Promise<T> | T) => {
    document.body.classList.add('summary-report-printing');
    try {
      const result = await action();
      return result;
    } finally {
      document.body.classList.remove('summary-report-printing');
    }
  };

  const handleSavePdf = async () => {
    if (!electronAPI?.savePdf) {
      if (onNotify) {
        onNotify('PDF export is only available in the desktop app. Use the print dialog to save as PDF in a browser.', 'error');
      } else {
        alert('PDF export is only available in the desktop app.');
      }
      return;
    }
    try {
      // Inject a temporary portrait @page rule for the summary PDF.
      const styleEl = document.createElement('style');
      styleEl.setAttribute('data-summary-pdf-style', 'true');
      styleEl.innerHTML = `
        @page { size: A4 portrait; margin: 12mm 12mm; }
        body { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
      `;
      document.head.appendChild(styleEl);

      const result = await runWithSummaryPrintContext(() => electronAPI.savePdf({ landscape: false }));

      styleEl.remove();

      if (!result) {
        return;
      }
      if (result.error) {
        if (onNotify) {
          onNotify(`Failed to save PDF: ${result.error}`, 'error');
        } else {
          alert(`Failed to save PDF: ${result.error}`);
        }
        return;
      }
      if (result.canceled) {
        return;
      }
      if (onNotify) {
        onNotify(result.filePath ? `PDF saved to ${result.filePath}` : 'PDF saved successfully.', 'success');
      } else {
        alert(result.filePath ? `PDF saved to ${result.filePath}` : 'PDF saved successfully.');
      }
    } catch (error) {
      console.error('Failed to save PDF', error);
      if (onNotify) {
        onNotify('Failed to save PDF. Please try again.', 'error');
      } else {
        alert('Failed to save PDF. Please try again.');
      }
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Summary Report"
      backdropClassName="summary-report-modal-backdrop"
      panelClassName="summary-report-modal-panel"
    >
      <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '0.5rem', marginBottom: '1rem' }} className="summary-report-controls no-print">
        <button onClick={() => setPeriod('1m')} style={period === '1m' ? activePeriodButtonStyle : periodButtonStyle}>Last 1 Month</button>
        <button onClick={() => setPeriod('6m')} style={period === '6m' ? activePeriodButtonStyle : periodButtonStyle}>Last 6 Months</button>
        <button onClick={() => setPeriod('12m')} style={period === '12m' ? activePeriodButtonStyle : periodButtonStyle}>Last 12 Months</button>
        <button onClick={() => setPeriod('all')} style={period === 'all' ? activePeriodButtonStyle : periodButtonStyle}>All Time</button>
        <button onClick={() => setPeriod('custom')} style={period === 'custom' ? activePeriodButtonStyle : periodButtonStyle}>Custom Range</button>
        <button onClick={handlePrintReport} style={printButtonStyle}>Print Report</button>
        <button onClick={handleSavePdf} style={pdfButtonStyle}>Save as PDF</button>
      </div>
      {period === 'custom' && (
        <div style={{ display: 'flex', justifyContent: 'center', gap: '1rem', marginBottom: '1rem', alignItems: 'center' }} className="summary-report-datepickers no-print">
          <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontWeight: 500 }}>
            Start Date:
            <input 
              type="date" 
              value={customStartDate} 
              onChange={e => setCustomStartDate(e.target.value)} 
              style={{ padding: '0.5rem', border: '1px solid var(--border-color)', borderRadius: '6px', fontSize: '0.9rem' }} 
            />
          </label>
          <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontWeight: 500 }}>
            End Date:
            <input 
              type="date" 
              value={customEndDate} 
              onChange={e => setCustomEndDate(e.target.value)} 
              style={{ padding: '0.5rem', border: '1px solid var(--border-color)', borderRadius: '6px', fontSize: '0.9rem' }} 
            />
          </label>
        </div>
      )}
      <div style={reportContainerStyle} className="printable-report-card">
        <div style={headerStyle}>
          <p style={{ fontSize: '1rem', margin: 0, fontWeight: 600 }}>{appTitle}</p>
          <h2 style={{ margin: '0.25rem 0', fontSize: '1.35rem', letterSpacing: '0.02em' }}>স্টক সারাংশ রিপোর্ট</h2>
          <p style={{ margin: 0, fontSize: '0.95rem' }}>শীটঃ {sheetName || '—'}</p>
        </div>
        <div style={metaGridStyle}>
          <div><strong>Report Date:</strong> {new Date().toLocaleDateString('en-GB')}</div>
          <div><strong>Reporting Period:</strong> {period === 'custom' ? (customStartDate && customEndDate ? `${new Date(customStartDate).toLocaleDateString('en-GB')} - ${new Date(customEndDate).toLocaleDateString('en-GB')}` : 'Custom Range') : periodLabelMap[period as Period]}</div>
          <div><strong>Prepared By:</strong> Inventory System</div>
          <div><strong>Verification Status:</strong> Auto-generated</div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1rem', marginBottom: '2rem' }} className="no-print">
          {summaryRows.map((row, index) => (
            <div key={row.label} style={{
              backgroundColor: row.bg || '#f9fafb',
              padding: '1.25rem',
              borderRadius: '12px',
              border: `2px solid ${row.color || '#e5e7eb'}`,
              boxShadow: row.highlight ? '0 8px 16px rgba(0,0,0,0.15)' : '0 4px 8px rgba(0,0,0,0.08)',
              transition: 'transform 0.2s, box-shadow 0.2s',
              transform: row.highlight ? 'scale(1.02)' : 'scale(1)'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.5rem' }}>
                <span style={{ fontSize: '1.5rem' }}>{row.icon || '📋'}</span>
                <h3 style={{ margin: 0, fontSize: '0.9rem', fontWeight: 600, color: '#374151' }}>{row.label}</h3>
              </div>
              <div style={{ fontSize: '1.5rem', fontWeight: 700, color: row.color || '#111827', marginTop: '0.5rem' }}>
                {row.value}
              </div>
            </div>
          ))}
        </div>
        <table style={summaryTableStyle}>
          <thead>
            <tr>
              <th style={{ ...summaryThStyle, width: '60px', textAlign: 'center' }}>Sl. No</th>
              <th style={summaryThStyle}>Metric</th>
              <th style={summaryThStyle}>Value</th>
            </tr>
          </thead>
          <tbody>
            {summaryRows.map((row, index) => (
              <tr key={row.label} style={row.highlight ? { backgroundColor: '#fff7ed' } : undefined}>
                <td style={{ ...summaryTdStyle, textAlign: 'center', fontWeight: 600 }}>{index + 1}</td>
                <td style={summaryTdStyle}>{row.label}</td>
                <td style={{ ...summaryTdStyle, fontWeight: row.highlight ? 700 : 500, color: row.color || (row.highlight ? '#166534' : '#111827') }}>
                  {row.value}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <p style={{ marginTop: '1rem', fontSize: '0.9rem', color: '#374151' }}>
          বিঃদ্রঃ সোনার ওজন ভরি → আনা → রতি → পয়েন্ট ক্রমে উপস্থাপন করা হয়েছে।
        </p>
      </div>
    </Modal>
  );
};

export default SummaryReportModal;