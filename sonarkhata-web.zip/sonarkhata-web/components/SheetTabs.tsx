import React from 'react';
import { AppState, Sheet } from '../types';

interface SheetTabsProps {
  sheets: { [id: string]: Sheet };
  activeSheetId: string;
  onSelectSheet: (id: string) => void;
  onAddSheetClick: () => void;
  onRenameSheetClick: (id: string, name: string) => void;
  onDeleteSheet: (id: string) => void;
}

const SheetTabs: React.FC<SheetTabsProps> = ({
  sheets,
  activeSheetId,
  onSelectSheet,
  onAddSheetClick,
  onRenameSheetClick,
  onDeleteSheet,
}) => {

  const handleDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    onDeleteSheet(id);
  };

  const containerStyles: React.CSSProperties = {
    display: 'flex',
    alignItems: 'center',
    borderBottom: '2px solid var(--border-color)',
    padding: '0 1.5rem',
    marginTop: '1.5rem',
    overflowX: 'auto',
    background: 'linear-gradient(to bottom, rgba(249,115,22,0.05), transparent)',
    borderRadius: '12px 12px 0 0',
  };

  const tabStyles: React.CSSProperties = {
    padding: '0.85rem 1.5rem',
    cursor: 'pointer',
    border: 'none',
    borderBottom: '3px solid transparent',
    backgroundColor: 'transparent',
    color: 'var(--text-secondary-color)',
    fontWeight: 600,
    display: 'flex',
    alignItems: 'center',
    gap: '0.5rem',
    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    borderRadius: '8px 8px 0 0',
    position: 'relative',
  };

  const activeTabStyles: React.CSSProperties = {
    ...tabStyles,
    color: 'var(--primary-color)',
    borderBottomColor: 'var(--primary-color)',
    background: 'rgba(249,115,22,0.08)',
    fontWeight: 700,
  };

  const buttonStyles: React.CSSProperties = {
    background: 'none',
    border: 'none',
    color: 'var(--text-secondary-color)',
    cursor: 'pointer',
    padding: '0.2rem',
    borderRadius: '4px',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center'
  };


  return (
    <div style={containerStyles} className="no-print">
      {/* FIX: Explicitly type 'sheet' as 'Sheet' to resolve property access errors. */}
      {Object.values(sheets).map((sheet: Sheet) => (
        <button
          key={sheet.id}
          style={sheet.id === activeSheetId ? activeTabStyles : tabStyles}
          onClick={() => onSelectSheet(sheet.id)}
        >
          {sheet.name}
           <span style={{ fontSize: '0.7rem', display: 'inline-flex', gap: '0.2rem', marginLeft: '0.5rem' }}>
              <button style={buttonStyles} title="Rename Sheet" onClick={(e) => { e.stopPropagation(); onRenameSheetClick(sheet.id, sheet.name); }}>✏️</button>
              <button style={buttonStyles} title="Delete Sheet" onClick={(e) => handleDelete(e, sheet.id)}>🗑️</button>
          </span>
        </button>
      ))}
      <button
        style={{...tabStyles, marginLeft: 'auto', color: 'var(--success-color)'}}
        onClick={onAddSheetClick}
        title="Add New Sheet"
      >
        + Add Sheet
      </button>
    </div>
  );
};

export default SheetTabs;
