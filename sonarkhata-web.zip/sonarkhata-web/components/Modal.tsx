import React from 'react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  backdropClassName?: string;
  panelClassName?: string;
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children, backdropClassName, panelClassName }) => {
  if (!isOpen) return null;

  const backdropStyle: React.CSSProperties = {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  };

  const modalStyle: React.CSSProperties = {
    backgroundColor: 'var(--card-background)',
    padding: '1.75rem 2.25rem',
    borderRadius: '16px',
    boxShadow: '0 20px 45px rgba(15, 23, 42, 0.25)',
    width: '90%',
    maxWidth: '820px',
    maxHeight: '90vh',
    overflowY: 'auto',
    position: 'relative',
    border: '1px solid var(--border-color)'
  };

  const headerStyle: React.CSSProperties = {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottom: '1px solid var(--border-color)',
    paddingBottom: '1rem',
    marginBottom: '1rem',
  };

  const titleStyle: React.CSSProperties = {
    margin: 0,
    fontSize: '1.25rem',
    fontWeight: 600,
    color: 'var(--text-color)'
  };

  const closeButtonStyle: React.CSSProperties = {
    background: 'none',
    border: 'none',
    fontSize: '1.5rem',
    cursor: 'pointer',
    lineHeight: 1,
    padding: '0.5rem',
    color: 'var(--text-secondary-color)'
  };

  return (
    <div style={backdropStyle} className={backdropClassName} onClick={onClose}>
      <div style={modalStyle} className={panelClassName} onClick={(e) => e.stopPropagation()}>
        <div style={headerStyle}>
          <h2 style={titleStyle}>{title}</h2>
          <button style={closeButtonStyle} onClick={onClose}>&times;</button>
        </div>
        {children}
      </div>
    </div>
  );
};

export default Modal;