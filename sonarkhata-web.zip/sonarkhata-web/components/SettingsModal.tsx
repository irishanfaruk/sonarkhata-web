import React, { useState, useEffect } from 'react';
import Modal from './Modal';

export interface SettingsState {
  theme: 'light' | 'dark';
  sheetApiUrl: string;
  dataFolderPath: string | null;
  shopName: string;
  adminUsername: string;
  adminPassword: string;
}

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: SettingsState;
  onChange: (settings: Partial<SettingsState>) => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onChange,
}) => {
  const [apiInput, setApiInput] = useState(settings.sheetApiUrl);
  const [currentUsername, setCurrentUsername] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [securityError, setSecurityError] = useState<string | null>(null);

  useEffect(() => {
    setApiInput(settings.sheetApiUrl);
  }, [settings.sheetApiUrl]);

  useEffect(() => {
    // Clear security form when settings dialog opens/closes
    if (isOpen) {
      setCurrentUsername('');
      setCurrentPassword('');
      setNewUsername('');
      setNewPassword('');
      setConfirmNewPassword('');
      setSecurityError(null);
    }
  }, [isOpen]);

  const handleToggleTheme = () => {
    onChange({ theme: settings.theme === 'light' ? 'dark' : 'light' });
  };

  const handleSaveApi = () => {
    onChange({ sheetApiUrl: apiInput.trim() });
  };

  const handleUpdateCredentials = () => {
    const expectedUser = (settings.adminUsername || 'admin').toLowerCase();
    const expectedPass = settings.adminPassword || 'admin123';

    if (currentUsername.trim().toLowerCase() !== expectedUser || currentPassword !== expectedPass) {
      setSecurityError('Current username or password is incorrect.');
      return;
    }

    if (!newPassword) {
      setSecurityError('New password cannot be empty.');
      return;
    }

    if (newPassword !== confirmNewPassword) {
      setSecurityError('New passwords do not match.');
      return;
    }

    const updates: Partial<SettingsState> = {
      adminPassword: newPassword,
    };
    if (newUsername.trim()) {
      updates.adminUsername = newUsername.trim();
    }

    onChange(updates);
    setSecurityError(null);
    setCurrentUsername('');
    setCurrentPassword('');
    setNewUsername('');
    setNewPassword('');
    setConfirmNewPassword('');
    alert('Admin username and password updated successfully.');
  };

  const handlePickFolder = async () => {
    const anyWindow: any = window;
    const api = anyWindow.electronAPI;
    if (!api || !api.selectDataFolder) {
      alert('Folder selection is only available in the desktop app.');
      return;
    }
    const folderPath = await api.selectDataFolder();
    if (folderPath) {
      onChange({ dataFolderPath: folderPath });
    }
  };

  const sectionTitle: React.CSSProperties = {
    fontWeight: 600,
    marginBottom: '0.5rem',
  };

  const labelStyle: React.CSSProperties = {
    display: 'block',
    marginBottom: '0.35rem',
    fontWeight: 500,
    color: 'var(--text-secondary-color)',
    fontSize: '0.9rem',
  };

  const inputStyle: React.CSSProperties = {
    width: '100%',
    padding: '0.7rem',
    borderRadius: '6px',
    border: '1px solid var(--border-color)',
    backgroundColor: 'var(--background-color)',
    color: 'var(--text-color)',
    fontSize: '0.9rem',
  };

  const buttonStyle: React.CSSProperties = {
    padding: '0.6rem 1.2rem',
    borderRadius: '6px',
    border: 'none',
    cursor: 'pointer',
    fontSize: '0.9rem',
    fontWeight: 500,
  };

  const secondaryButton: React.CSSProperties = {
    ...buttonStyle,
    backgroundColor: 'var(--card-background)',
    border: '1px solid var(--border-color)',
    color: 'var(--text-color)',
  };

  const primaryButton: React.CSSProperties = {
    ...buttonStyle,
    backgroundColor: 'var(--primary-color)',
    color: '#111827',
  };

  const infoText: React.CSSProperties = {
    fontSize: '0.8rem',
    color: 'var(--text-secondary-color)',
    marginTop: '0.25rem',
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Settings">
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
        {/* Shop info */}
        <section>
          <h3 style={sectionTitle}>Shop Information</h3>
          <label style={labelStyle} htmlFor="shop-name">
            Shop Name
          </label>
          <input
            id="shop-name"
            style={inputStyle}
            type="text"
            value={settings.shopName}
            onChange={(e) => onChange({ shopName: e.target.value })}
            placeholder="e.g., Sonarkhata Jewellers"
          />
        </section>

        {/* Appearance */}
        <section>
          <h3 style={sectionTitle}>Appearance</h3>
          <label style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', cursor: 'pointer' }}>
            <input
              type="checkbox"
              checked={settings.theme === 'dark'}
              onChange={handleToggleTheme}
            />
            <span>Dark Mode</span>
          </label>
        </section>

        {/* Cloud Sync */}
        <section>
          <h3 style={sectionTitle}>Cloud Sync (API)</h3>
          <label style={labelStyle} htmlFor="sheet-api-url">
            Google Apps Script URL
          </label>
          <input
            id="sheet-api-url"
            style={inputStyle}
            type="text"
            value={apiInput}
            onChange={(e) => setApiInput(e.target.value)}
          />
          <div style={{ marginTop: '0.5rem', display: 'flex', gap: '0.75rem' }}>
            <button type="button" style={primaryButton} onClick={handleSaveApi}>
              Save API URL
            </button>
          </div>
          <p style={infoText}>
            Enter your Google Apps Script web app URL. Required for Export and Import.
          </p>
        </section>

        {/* Data storage */}
        <section>
          <h3 style={sectionTitle}>Data Storage</h3>
          <p style={labelStyle}>Current Data Location</p>
          <p style={{ fontSize: '0.9rem', marginBottom: '0.5rem' }}>
            {settings.dataFolderPath || 'Default app storage (local browser data).'}
          </p>
          <button
            type="button"
            style={secondaryButton}
            onClick={handlePickFolder}
          >
            Change Folder
          </button>
          <p style={infoText}>
            When a folder is selected, your inventory data file is saved there as
            <strong> sonarkhata-data.json</strong>. It will only be removed if you
            delete it manually.
          </p>
        </section>

        {/* Admin Security */}
        <section>
          <h3 style={sectionTitle}>Admin Security</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: '0.75rem' }}>
            <div>
              <label style={labelStyle} htmlFor="current-username">Current Username</label>
              <input
                id="current-username"
                style={inputStyle}
                type="text"
                value={currentUsername}
                onChange={(e) => setCurrentUsername(e.target.value)}
              />
            </div>
            <div>
              <label style={labelStyle} htmlFor="current-password">Current Password</label>
              <input
                id="current-password"
                style={inputStyle}
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
              />
            </div>
            <div>
              <label style={labelStyle} htmlFor="new-username">New Username (optional)</label>
              <input
                id="new-username"
                style={inputStyle}
                type="text"
                value={newUsername}
                onChange={(e) => setNewUsername(e.target.value)}
                placeholder={settings.adminUsername ? 'Leave empty to keep current username' : undefined}
              />
            </div>
            <div>
              <label style={labelStyle} htmlFor="new-password">New Password</label>
              <input
                id="new-password"
                style={inputStyle}
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
              />
            </div>
            <div>
              <label style={labelStyle} htmlFor="confirm-new-password">Confirm New Password</label>
              <input
                id="confirm-new-password"
                style={inputStyle}
                type="password"
                value={confirmNewPassword}
                onChange={(e) => setConfirmNewPassword(e.target.value)}
              />
            </div>
          </div>
          {securityError && (
            <p style={{ ...infoText, color: 'var(--danger-color)' }}>{securityError}</p>
          )}
          <div style={{ marginTop: '0.75rem' }}>
            <button type="button" style={primaryButton} onClick={handleUpdateCredentials}>
              Update Admin Login
            </button>
          </div>
        </section>
      </div>
    </Modal>
  );
};

export default SettingsModal;


