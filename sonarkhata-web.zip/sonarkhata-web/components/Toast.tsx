import React, { useEffect } from 'react';

interface ToastProps {
  message: string;
  type: 'success' | 'error';
  onClose: () => void;
}

const Toast: React.FC<ToastProps> = ({ message, type, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 3000);
    return () => clearTimeout(timer);
  }, [onClose]);

  const baseStyle: React.CSSProperties = {
    position: 'fixed',
    top: '20px',
    right: '20px',
    padding: '1rem 1.5rem',
    borderRadius: '6px',
    color: 'white',
    boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)',
    zIndex: 2000,
    display: 'flex',
    alignItems: 'center',
    gap: '1rem'
  };

  const successStyle: React.CSSProperties = {
    ...baseStyle,
    backgroundColor: 'var(--success-color)',
  };

  const errorStyle: React.CSSProperties = {
    ...baseStyle,
    backgroundColor: 'var(--danger-color)',
  };
  
  const closeButtonStyle: React.CSSProperties = {
    background: 'none',
    border: 'none',
    color: 'white',
    fontSize: '1.2rem',
    cursor: 'pointer',
    lineHeight: 1
  }

  return (
    <div className="no-print" style={type === 'success' ? successStyle : errorStyle}>
      <span>{message}</span>
      <button onClick={onClose} style={closeButtonStyle}>&times;</button>
    </div>
  );
};

export default Toast;
