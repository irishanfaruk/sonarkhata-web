import React, { useState, useEffect } from 'react';
import Modal from './Modal';
import { Transaction, Weight } from '../types';

interface AddEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (entry: Omit<Transaction, 'id' | 'profit'> & { id?: string }) => void;
  existingTransaction: Transaction | null;
  onOpenCalculator?: (weight: Weight, targetField: 'purchasePrice' | 'salePrice', onPriceCalculated: (price: number) => void) => void;
}

const initialWeight: Weight = { vori: 0, ana: 0, roti: 0, point: 0 };

const AddEntryModal: React.FC<AddEntryModalProps> = ({ isOpen, onClose, onSave, existingTransaction, onOpenCalculator }) => {
  const [product, setProduct] = useState('');
  const [purchaseDate, setPurchaseDate] = useState(new Date().toISOString().split('T')[0]);
  const [saleDate, setSaleDate] = useState('');
  const [tokenNumber, setTokenNumber] = useState('');
  const [weight, setWeight] = useState<Weight>(initialWeight);
  const [purchasePrice, setPurchasePrice] = useState<string>('');
  const [salePrice, setSalePrice] = useState<string>('');
  const [comment, setComment] = useState('');
  const [isSoldManually, setIsSoldManually] = useState(false);
  const [calculatedProfit, setCalculatedProfit] = useState<number | null>(null);

  const handleWeightChange = (unit: keyof Weight, value: string) => {
    const numericValue = parseInt(value, 10);
    setWeight(prev => ({ ...prev, [unit]: isNaN(numericValue) ? 0 : numericValue }));
  };

  const handleOpenCalculator = (target: 'purchasePrice' | 'salePrice') => {
    if (onOpenCalculator) {
      onOpenCalculator(weight, target, (price: number) => {
        if (target === 'purchasePrice') {
          setPurchasePrice(price.toFixed(2));
        } else if (target === 'salePrice') {
          setSalePrice(price.toFixed(2));
        }
      });
    }
  };
  
  useEffect(() => {
    const pPrice = Number(purchasePrice) || 0;
    const sPrice = Number(salePrice) || 0;

    if (pPrice > 0 && sPrice > 0) {
        const profit = sPrice - pPrice;
        setCalculatedProfit(profit);
    } else {
        setCalculatedProfit(null);
    }
  }, [purchasePrice, salePrice]);


  useEffect(() => {
    if (existingTransaction) {
      setProduct(existingTransaction.product);
      setPurchaseDate(existingTransaction.purchaseDate ? existingTransaction.purchaseDate.split('T')[0] : new Date().toISOString().split('T')[0]);
      setSaleDate(existingTransaction.saleDate ? existingTransaction.saleDate.split('T')[0] : '');
      setTokenNumber(existingTransaction.tokenNumber || '');
      setWeight(existingTransaction.weight || initialWeight);
      setPurchasePrice(existingTransaction.purchasePrice?.toString() || '');
      setSalePrice(existingTransaction.salePrice?.toString() || '');
      setComment(existingTransaction.comment || '');
      setIsSoldManually(existingTransaction.isSoldManually || false);
    } else {
      // Reset form for new entry
      setProduct('');
      setPurchaseDate(new Date().toISOString().split('T')[0]);
      setSaleDate('');
      setTokenNumber('');
      setWeight(initialWeight);
      setPurchasePrice('');
      setSalePrice('');
      setComment('');
      setIsSoldManually(false);
    }
  }, [existingTransaction, isOpen]);
  
  const convertWeightToVori = (w: Weight): number => {
      const vori = w.vori || 0;
      const ana = w.ana || 0;
      const roti = w.roti || 0;
      const point = w.point || 0;
      return vori + (ana / 16) + (roti / 96) + (point / 960);
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const totalWeightInVori = convertWeightToVori(weight);
    
    onSave({
      id: existingTransaction?.id,
      product,
      purchaseDate,
      saleDate: saleDate || null,
      tokenNumber: tokenNumber || null,
      weight: totalWeightInVori > 0 ? weight : null,
      totalWeightInVori: totalWeightInVori > 0 ? totalWeightInVori : null,
      purchasePrice: purchasePrice ? parseFloat(purchasePrice) : null,
      salePrice: salePrice ? parseFloat(salePrice) : null,
      comment: comment || null,
      isSoldManually,
    });
  };
  
  // STYLES
  const formGridStyle: React.CSSProperties = { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1.5rem' };
  const formGroupStyle: React.CSSProperties = { display: 'flex', flexDirection: 'column' };
  const labelStyle: React.CSSProperties = { marginBottom: '0.5rem', fontWeight: 500, color: 'var(--text-secondary-color)', fontSize: '0.9rem' };
  const inputStyle: React.CSSProperties = { width: '100%', padding: '0.7rem', border: '1px solid var(--border-color)', borderRadius: '6px', backgroundColor: 'var(--background-color)', color: 'var(--text-color)', fontSize: '1rem' };
  const weightGridStyle: React.CSSProperties = { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' };
  const fullWidthStyle: React.CSSProperties = { gridColumn: '1 / -1' };
  const buttonContainer: React.CSSProperties = { display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '2rem', gridColumn: '1 / -1' };
  const profitDisplayStyle: React.CSSProperties = {
    ...fullWidthStyle,
    textAlign: 'center',
    padding: '1rem',
    borderRadius: '6px',
    marginTop: '0.5rem',
    fontWeight: 'bold',
    backgroundColor: calculatedProfit !== null ? (calculatedProfit >= 0 ? 'rgba(34, 197, 94, 0.1)' : 'rgba(239, 68, 68, 0.1)') : 'var(--background-color)',
    color: calculatedProfit !== null ? (calculatedProfit >= 0 ? 'var(--success-color)' : 'var(--danger-color)') : 'var(--text-secondary-color)',
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={existingTransaction ? 'Edit Entry' : 'Add New Entry'}>
      <form onSubmit={handleSubmit}>
        <div style={formGridStyle}>
          <div style={{...formGroupStyle, ...fullWidthStyle}}>
            <label style={labelStyle} htmlFor="product">Product Name</label>
            <input style={inputStyle} type="text" id="product" value={product} onChange={(e) => setProduct(e.target.value)} required autoFocus />
          </div>
          
          <div style={formGroupStyle}>
            <label style={labelStyle} htmlFor="purchaseDate">Purchase Date</label>
            <input style={inputStyle} type="date" id="purchaseDate" value={purchaseDate} onChange={(e) => setPurchaseDate(e.target.value)} required />
          </div>

          <div style={formGroupStyle}>
            <label style={labelStyle} htmlFor="saleDate">Sale Date</label>
            <input style={inputStyle} type="date" id="saleDate" value={saleDate} onChange={(e) => setSaleDate(e.target.value)} />
          </div>

          <div style={formGroupStyle}>
            <label style={labelStyle} htmlFor="tokenNumber">Token Number</label>
            <input style={inputStyle} type="text" id="tokenNumber" value={tokenNumber} onChange={(e) => setTokenNumber(e.target.value)} />
          </div>

          <div style={formGroupStyle}>
            <label style={labelStyle}>Weight</label>
            <div style={weightGridStyle}>
                <input style={inputStyle} type="number" placeholder="Vori" value={weight.vori || ''} onChange={(e) => handleWeightChange('vori', e.target.value)} />
                <input style={inputStyle} type="number" placeholder="Ana" value={weight.ana || ''} onChange={(e) => handleWeightChange('ana', e.target.value)} />
                <input style={inputStyle} type="number" placeholder="Roti" value={weight.roti || ''} onChange={(e) => handleWeightChange('roti', e.target.value)} />
                <input style={inputStyle} type="number" placeholder="Point" value={weight.point || ''} onChange={(e) => handleWeightChange('point', e.target.value)} />
            </div>
          </div>
          
          <div style={formGroupStyle}>
            <label style={labelStyle} htmlFor="purchasePrice">Purchase Price (৳)</label>
            <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
              <input style={{...inputStyle, flex: 1}} type="number" step="0.01" id="purchasePrice" placeholder="e.g., 50000" value={purchasePrice} onChange={(e) => setPurchasePrice(e.target.value)} />
              <button
                type="button"
                onClick={() => handleOpenCalculator('purchasePrice')}
                style={{
                  padding: '0.7rem',
                  border: '1px solid var(--border-color)',
                  borderRadius: '6px',
                  backgroundColor: 'var(--background-color)',
                  color: 'var(--text-color)',
                  cursor: 'pointer',
                  fontSize: '1rem',
                  minWidth: '40px'
                }}
                title="Open Calculator"
              >
                🧮
              </button>
            </div>
          </div>

          <div style={formGroupStyle}>
            <label style={labelStyle} htmlFor="salePrice">Sale Price (৳)</label>
            <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
              <input style={{...inputStyle, flex: 1}} type="number" step="0.01" id="salePrice" placeholder="e.g., 55000" value={salePrice} onChange={(e) => setSalePrice(e.target.value)} />
              <button
                type="button"
                onClick={() => handleOpenCalculator('salePrice')}
                style={{
                  padding: '0.7rem',
                  border: '1px solid var(--border-color)',
                  borderRadius: '6px',
                  backgroundColor: 'var(--background-color)',
                  color: 'var(--text-color)',
                  cursor: 'pointer',
                  fontSize: '1rem',
                  minWidth: '40px'
                }}
                title="Open Calculator"
              >
                🧮
              </button>
            </div>
          </div>

          <div style={{...formGroupStyle, ...fullWidthStyle}}>
              <label style={labelStyle} htmlFor="comment">Comment</label>
              <textarea style={{...inputStyle, height: '80px', resize: 'vertical'}} id="comment" value={comment} onChange={(e) => setComment(e.target.value)}></textarea>
          </div>
          
          <div style={{ ...fullWidthStyle, display: 'flex', alignItems: 'center', gap: '0.75rem', marginTop: '0.5rem' }}>
              <input
                type="checkbox"
                id="isSoldManually"
                checked={isSoldManually}
                onChange={(e) => setIsSoldManually(e.target.checked)}
                style={{ width: '1.2rem', height: '1.2rem', cursor: 'pointer' }}
              />
              <label htmlFor="isSoldManually" style={{...labelStyle, marginBottom: 0, cursor: 'pointer'}}>Manually Mark as SOLD</label>
          </div>

          {calculatedProfit !== null && (
            <div style={profitDisplayStyle}>
              Calculated Profit: ৳ {calculatedProfit.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          )}
          
          <div style={buttonContainer}>
            <button type="button" onClick={onClose} style={{padding: '0.6rem 1.2rem', border: '1px solid var(--border-color)', borderRadius: '6px', cursor: 'pointer', backgroundColor: 'transparent', color: 'var(--text-color)'}}>Cancel</button>
            <button type="submit" style={{padding: '0.6rem 1.2rem', border: 'none', borderRadius: '6px', cursor: 'pointer', backgroundColor: 'var(--primary-color)', color: '#111827', fontWeight: 'bold'}}>
                {existingTransaction ? 'Update Entry' : 'Save Entry'}
            </button>
          </div>
        </div>
      </form>
    </Modal>
  );
};

export default AddEntryModal;
