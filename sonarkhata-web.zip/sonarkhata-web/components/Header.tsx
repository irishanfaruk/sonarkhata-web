import React from 'react';

interface HeaderProps {
  onAddEntryClick: () => void;
  onSummaryReportClick: () => void;
  onCalculatorClick: () => void;
  onSyncClick: () => void;
  onSettingsClick: () => void;
  shopName: string;
  isSyncing: boolean;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

const Header: React.FC<HeaderProps> = ({
  onAddEntryClick,
  onSummaryReportClick,
  onCalculatorClick,
  onSyncClick,
  onSettingsClick,
  shopName,
  isSyncing,
  searchQuery,
  onSearchChange
}) => {
  const headerStyles: React.CSSProperties = {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '1rem 2rem',
    background: 'linear-gradient(135deg, #f97316 0%, #ea580c 50%, #dc2626 100%)',
    borderRadius: '0 0 16px 16px',
    boxShadow: '0 20px 40px rgba(249, 115, 22, 0.3), 0 0 0 1px rgba(255,255,255,0.1) inset',
    gap: '1.5rem',
    flexWrap: 'wrap',
    color: '#ffffff',
    backdropFilter: 'blur(10px)',
    border: '1px solid rgba(255,255,255,0.1)',
    position: 'relative',
    overflow: 'hidden'
  };

  const titleStyles: React.CSSProperties = {
    margin: 0,
    fontSize: '1.6rem',
    fontWeight: 800,
    color: '#ffffff',
    whiteSpace: 'nowrap',
    textShadow: '0 2px 8px rgba(0,0,0,0.2)',
    letterSpacing: '0.5px'
  };

  const buttonStyles: React.CSSProperties = {
    padding: '0.7rem 1.4rem',
    border: 'none',
    borderRadius: '10px',
    fontSize: '0.95rem',
    fontWeight: 600,
    cursor: 'pointer',
    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    whiteSpace: 'nowrap',
    boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
    position: 'relative',
    overflow: 'hidden'
  };

  const primaryButtonStyles: React.CSSProperties = {
    ...buttonStyles,
    background: 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)',
    color: '#ffffff',
    boxShadow: '0 6px 20px rgba(37, 99, 235, 0.4)',
  };
  
  const secondaryButtonStyles: React.CSSProperties = {
    ...buttonStyles,
    background: 'rgba(255,255,255,0.12)',
    color: '#ffffff',
    border: '1px solid rgba(255,255,255,0.3)',
    backdropFilter: 'blur(10px)',
  };

  const syncButtonStyles: React.CSSProperties = {
    ...buttonStyles,
    backgroundColor: '#0f172a',
    color: '#e5e7eb',
    border: '1px solid rgba(15,23,42,0.4)',
    boxShadow: '0 0 0 rgba(15,23,42,0)',
    transition: 'box-shadow 0.3s ease, transform 0.2s ease',
  };

  const searchInputStyles: React.CSSProperties = {
    padding: '0.7rem 1.2rem',
    border: '2px solid rgba(255,255,255,0.3)',
    borderRadius: '10px',
    background: 'rgba(255,255,255,0.95)',
    color: '#111827',
    fontSize: '0.95rem',
    width: '100%',
    maxWidth: '280px',
    boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
    transition: 'all 0.3s',
    outline: 'none'
  };

  return (
    <header style={headerStyles} className="no-print">
      <h1 style={titleStyles}>{shopName}</h1>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexGrow: 1, justifyContent: 'flex-end', flexWrap: 'wrap' }}>
        <input
            type="text"
            placeholder="Search by Token Number..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            style={searchInputStyles}
        />
          <button 
            style={secondaryButtonStyles} 
            onClick={onCalculatorClick}
            onMouseOver={(e) => { e.currentTarget.style.backgroundColor = 'rgba(245, 158, 11, 0.1)'; }}
            onMouseOut={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
          >
            Gold Calculator
          </button>
          <button 
            style={secondaryButtonStyles} 
            onClick={onSummaryReportClick}
            onMouseOver={(e) => { e.currentTarget.style.backgroundColor = 'rgba(245, 158, 11, 0.1)'; }}
            onMouseOut={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
          >
            Summary Report
          </button>
          <button
            style={{
              ...syncButtonStyles,
              opacity: isSyncing ? 0.6 : 1,
              cursor: isSyncing ? 'not-allowed' : 'pointer'
            }}
            onClick={onSyncClick}
            disabled={isSyncing}
            onMouseOver={(e) => {
              if (isSyncing) return;
              e.currentTarget.style.boxShadow = '0 0 14px rgba(15,23,42,0.5)';
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.boxShadow = '0 0 0 rgba(15,23,42,0)';
            }}
          >
            {isSyncing ? 'Syncing…' : '☁️ Sync'}
          </button>
          <button 
            style={secondaryButtonStyles}
            onClick={onSettingsClick}
            onMouseOver={(e) => { e.currentTarget.style.backgroundColor = 'rgba(15,23,42,0.2)'; }}
            onMouseOut={(e) => { e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.08)'; }}
          >
            Settings
          </button>
          <button 
            style={primaryButtonStyles} 
            onClick={onAddEntryClick}
            onMouseOver={(e) => e.currentTarget.style.backgroundColor = 'var(--primary-hover)'}
            onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'var(--primary-color)'}
          >
            Add New Entry
          </button>
      </div>
    </header>
  );
};

export default Header;