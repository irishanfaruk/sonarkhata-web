import React from 'react';
import Modal from './Modal';

interface SyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExport: () => void;
  onImport: () => void;
  isBusy: boolean;
}

const SyncModal: React.FC<SyncModalProps> = ({
  isOpen,
  onClose,
  onExport,
  onImport,
  isBusy,
}) => {
  const sectionStyle: React.CSSProperties = {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.75rem',
    marginTop: '0.5rem',
  };

  const buttonBase: React.CSSProperties = {
    width: '100%',
    padding: '0.8rem 1rem',
    borderRadius: '8px',
    border: 'none',
    cursor: isBusy ? 'not-allowed' : 'pointer',
    fontWeight: 600,
    fontSize: '0.95rem',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '0.5rem',
    opacity: isBusy ? 0.7 : 1,
  };

  const exportButton: React.CSSProperties = {
    ...buttonBase,
    background:
      'linear-gradient(90deg, rgba(59,130,246,1), rgba(56,189,248,1))',
    color: '#ffffff',
  };

  const importButton: React.CSSProperties = {
    ...buttonBase,
    backgroundColor: 'rgba(15,23,42,0.05)',
    color: 'var(--text-color)',
    border: '1px solid var(--border-color)',
  };

  const infoText: React.CSSProperties = {
    fontSize: '0.85rem',
    color: 'var(--text-secondary-color)',
    marginTop: '0.5rem',
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Cloud Sync">
      <div>
        <p style={infoText}>
          Backup your current sheet to Google Sheets or restore data from the
          cloud. Export uses your active sheet&apos;s rows only.
        </p>
        <div style={sectionStyle}>
          <button
            type="button"
            style={exportButton}
            onClick={onExport}
            disabled={isBusy}
          >
            ☁️ Export to Cloud
          </button>
          <button
            type="button"
            style={importButton}
            onClick={onImport}
            disabled={isBusy}
          >
            ⬇️ Import from Cloud
          </button>
        </div>
        <p style={{ ...infoText, marginTop: '1rem' }}>
          Note: Import will replace the current sheet&apos;s entries with data
          from Google Sheets.
        </p>
      </div>
    </Modal>
  );
};

export default SyncModal;



